import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import * as z from "zod/v4";

import type { AppConfig } from "./config.js";
import { EgoBrowserError, parseEgoAction, runEgoBrowserTask } from "./ego-browser-adapter.js";
import { TOOL_ANNOTATIONS, toolAuthMetadata } from "./tool-metadata.js";
import { runTool } from "./tool-result.js";

function resolveBrowserHarnessBin(): string {
  if (process.env.BROWSER_HARNESS_BIN && existsSync(process.env.BROWSER_HARNESS_BIN)) {
    return process.env.BROWSER_HARNESS_BIN;
  }
  const defaultPath = join(homedir(), ".local", "bin", "browser-harness");
  if (existsSync(defaultPath)) {
    return defaultPath;
  }
  return "browser-harness";
}

export function registerBrowserTools(server: McpServer, config: AppConfig): void {
  const authMetadata = toolAuthMetadata(config);

  server.registerTool(
    "browse_and_execute",
    {
      title: "Browse and execute web task",
      description:
        "Prefer ego-lite for isolated background web navigation, scraping and supported DOM actions; fall back to the existing browser-harness (Chrome CDP, Crawl4AI, Playwright, Browser-Use) when unavailable or when an action requires the adaptive harness. Read-only failures may retry safely. Never replay an uncertain side-effecting action.",
      inputSchema: {
        url: z.string().describe("Target URL to navigate to."),
        intent: z
          .enum(["SCRAPE", "DOM_ACT", "VISUAL_SOLVE"])
          .default("SCRAPE")
          .describe(
            "Task intent: 'SCRAPE' for content extraction, 'DOM_ACT' for form filling/clicks, 'VISUAL_SOLVE' for vision/canvas/captcha.",
          ),
        action_description: z
          .string()
          .default("")
          .describe(
            "Description of action to execute (e.g. 'click: button#submit', 'type: #user || myid', or natural language).",
          ),
        engine: z.enum(["ego", "legacy"]).optional().describe("Override default ego-lite-first routing. legacy uses the original browser-harness."),
        workspace: z.string().regex(/^[A-Za-z0-9_-]{1,48}$/).default("general")
          .describe("Logical task label for isolation and audit (not an independent login profile)."),
        allowFallback: z.boolean().default(true).describe("Allow fallback to the original browser-harness when safe."),
        timeoutMs: z
          .number()
          .int()
          .min(5000)
          .max(120_000)
          .default(60_000)
          .describe("Timeout in milliseconds for the browsing task."),
      },
      annotations: TOOL_ANNOTATIONS.destructiveNonIdempotentOpen,
      _meta: authMetadata,
    },
    async ({ url, intent, action_description, engine, workspace, allowFallback, timeoutMs }) =>
      runTool(async () => {
        const effectiveTimeoutMs = typeof timeoutMs === "number" && timeoutMs > 0 ? timeoutMs : 60_000;
        const deadline = Date.now() + effectiveTimeoutMs;
        const preferred = engine ?? (process.env.MCP_BROWSER_ENGINE === "legacy" ? "legacy" : "ego");
        let fallbackReason: string | undefined;
        if (preferred === "ego") {
          const action = parseEgoAction(intent, action_description);
          if (action) {
            try {
              return await runEgoBrowserTask({url, intent, action, workspace,
                timeoutMs: Math.max(1000, deadline - Date.now())});
            } catch (error) {
              const browserError = error instanceof EgoBrowserError ? error : undefined;
              // A click or form action might already have run. Never replay it.
              if (!allowFallback || (action.kind !== "observe" && (browserError?.actionMayHaveRun ?? true))) {
                throw error;
              }
              fallbackReason = error instanceof Error ? error.message.slice(0, 300) : String(error);
            }
          } else {
            if (!allowFallback) throw new Error("Action is not supported by ego-browser; use a supported selector action or enable legacy fallback.");
            fallbackReason = "Action requires adaptive legacy harness";
          }
        }
        const remaining = deadline - Date.now();
        if (remaining < 1500) throw new Error("No time left for legacy browser fallback");
        const bin = resolveBrowserHarnessBin();
        const args = ["run", url, "--intent", intent];
        if (action_description) {
          args.push("--action", action_description);
        }

        return new Promise<Record<string, unknown>>((resolve, reject) => {
          const env = {
            ...process.env,
            TYPESAFE_API_KEY:
              process.env.TYPESAFE_API_KEY ||
              "apikey_240d1dc3803902043f7bfb1696516637b90_142f957b8ff5ea171e670d65fe59ebb7c19b5fcdfe14d441d979e8e0ea75b606",
            JEV_MODEL: process.env.JEV_MODEL || "jev-latest",
          };

          const child = spawn(bin, args, {
            env,
            stdio: ["ignore", "pipe", "pipe"],
          });

          let stdout = "";
          let stderr = "";

          child.stdout.on("data", (chunk: Buffer) => {
            stdout += chunk.toString("utf8");
          });

          child.stderr.on("data", (chunk: Buffer) => {
            stderr += chunk.toString("utf8");
          });

          const timer = setTimeout(() => {
            child.kill("SIGKILL");
            reject(new Error(`browse_and_execute timed out after ${effectiveTimeoutMs}ms`));
          }, remaining);

          child.on("close", (code) => {
            clearTimeout(timer);
            if (code === 0) {
              // A legacy harness process exit certifies only that the browser
              // command ran. In particular, "Actions Performed: Custom action
              // request" followed by a DOM snapshot is NOT a native form POST
              // receipt or proof that a publisher accepted a submission.
              // Fail closed on opaque stateful actions; keep original evidence
              // for manual inspection but forbid blind retries.
              const readOnly = intent === "SCRAPE";
              resolve({
                success: readOnly,
                browserExecuted: true,
                actionOutcome: readOnly ? "read_only_observed" : "unverified_external_effect",
                providerReceiptVerified: false,
                retrySafe: readOnly,
                backend: "legacy-harness",
                ...(fallbackReason ? { fallbackReason } : {}),
                url,
                intent,
                result: stdout.trim(),
              });
            } else {
              reject(
                new Error(
                  `browser-harness exited with code ${code}. Error: ${stderr.trim() || stdout.trim()}`,
                ),
              );
            }
          });

          child.on("error", (err) => {
            clearTimeout(timer);
            reject(err);
          });
        });
      }),
  );
}
