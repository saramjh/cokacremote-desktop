import type { ContextClient } from './context-local.js';
type Config = Record<string, unknown>;
export function mergeContextHooks(existing: Config, client: ContextClient, command: string): Config {
  const result = structuredClone(existing);
  const hooks = (result.hooks ?? {}) as Record<string, Array<Record<string, unknown>>>;
  result.hooks = hooks;
  const events = client === 'cursor' ? ['sessionStart', 'beforeSubmitPrompt', 'stop', 'preCompact', 'preToolUse']
    : client === 'gemini' ? ['SessionStart', 'BeforeAgent', 'AfterAgent', 'PreCompress', 'BeforeTool']
      : ['SessionStart', 'UserPromptSubmit', 'Stop', 'PreCompact', 'PreToolUse'];
  for (const event of events) {
    const handler = { type: 'command', name: 'agent-context', command: `${command} hook --client ${client}`, timeout: client === 'gemini' ? 10000 : 10 };
    const previous = hooks[event] ?? [];
    const kept = previous.filter(entry => client === 'cursor' ? entry.name !== 'agent-context'
      : !Array.isArray(entry.hooks) || !entry.hooks.some((hook: Record<string, unknown>) => hook.name === 'agent-context'));
    if (client === 'cursor') hooks[event] = [...kept, { ...handler, ...(event === 'stop' ? { loop_limit: 1 } : {}) }];
    else hooks[event] = [...kept, { ...(event === 'PreToolUse' || event === 'BeforeTool' ? { matcher: '.*project_context_checkpoint.*' } : {}), hooks: [handler] }];
  }
  if (client === 'cursor') result.version ??= 1;
  return result;
}
