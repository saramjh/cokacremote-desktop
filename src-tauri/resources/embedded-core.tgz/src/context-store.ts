import { createHash, randomUUID } from "node:crypto";
import { mkdir, open, readFile, rename, rm, writeFile } from "node:fs/promises";
import path from "node:path";

const lists = ["decisions", "rejected", "constraints", "openIssues", "next", "files", "verification"] as const;
type ListField = typeof lists[number];
type Field = ListField | "objective" | "intent";
export type CheckpointData = {
  summary: string; objective?: string; intent?: string; eventType: string;
  decisions: string[]; rejected: string[]; constraints: string[]; openIssues: string[];
  next: string[]; files: string[]; verification: string[];
  eventId?: string; baseRevision?: number; clearFields?: Field[]; replaceFields?: ListField[];
  reconcileProjection?: boolean;
  captureToken?: string;
};
type Baseline = { supported: boolean; gitRoot?: string; head?: string; fingerprint?: string; changedPaths: string[]; error?: string };
export type Snapshot = {
  version: 2; revision: number; updatedAt: string; data: CheckpointData;
  baseline: Baseline; eventIds: Record<string, string>;
  verificationEvidence?: { recordedAt: string; revision: number; fingerprint: string | null } | null;
  captureEvidence?: { token: string; revision: number };
};
const maxEventBytes = 128 * 1024;

async function optionalText(file: string): Promise<string | null> {
  try { return await readFile(file, "utf8"); } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}
function validSnapshot(value: unknown): value is Snapshot {
  if (!value || typeof value !== "object") return false;
  const item = value as Snapshot;
  return item.version === 2 && Number.isSafeInteger(item.revision) && item.revision > 0 &&
    typeof item.updatedAt === "string" && typeof item.data?.summary === "string" &&
    lists.every(key => Array.isArray(item.data[key]) && item.data[key].every(v => typeof v === "string")) &&
    Boolean(item.baseline && typeof item.baseline.supported === "boolean" && item.eventIds);
}
function parseSnapshot(raw: string | null): Snapshot | null {
  try { const parsed: unknown = JSON.parse(raw ?? "null"); return validSnapshot(parsed) ? parsed : null; } catch { return null; }
}

// Read only the tail on ordinary recovery, regardless of how long history is.
// Every complete journal record is limited to 128KiB, so 256KiB includes the last.
async function latestEvent(dir: string): Promise<Snapshot | null> {
  let handle;
  try {
    handle = await open(path.join(dir, "CONVERSATION.jsonl"), "r");
    const size = (await handle.stat()).size;
    const start = Math.max(0, size - 2 * maxEventBytes);
    const buffer = Buffer.alloc(size - start);
    await handle.read(buffer, 0, buffer.length, start);
    const raw = buffer.toString("utf8");
    const lines = raw.split("\n");
    lines.pop(); // incomplete final records never commit
    if (start > 0) lines.shift();
    for (const line of lines.reverse()) {
      try { const event = JSON.parse(line) as { snapshot?: unknown }; if (validSnapshot(event.snapshot)) return event.snapshot; } catch { /* interrupted append */ }
    }
    return null;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  } finally { await handle?.close(); }
}

async function atomicText(file: string, value: string): Promise<void> {
  const temp = `${file}.${randomUUID()}.tmp`;
  try { await writeFile(temp, value, "utf8"); await rename(temp, file); } finally { await rm(temp, { force: true }); }
}

// Lock the existing context owner across HTTP requests and server processes.
// A dead local process's lock can be reclaimed; a live process is never stolen.
export async function withContextLock<T>(dir: string, operation: () => Promise<T>): Promise<T> {
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, "WRITE.lock");
  const deadline = Date.now() + 5000;
  let lock;
  while (!lock) {
    try {
      lock = await open(file, "wx");
      await lock.writeFile(JSON.stringify({ pid: process.pid }));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      // Serialize stale-lock recovery so two reclaimers cannot unlink a new
      // writer's lock after observing the same dead owner.
      let reclaimer;
      const reclaimPath = path.join(dir, "RECLAIM.lock");
      try {
        reclaimer = await open(reclaimPath, "wx");
        const owner = JSON.parse(await readFile(file, "utf8")) as { pid?: number };
        if (Number.isInteger(owner.pid) && owner.pid! > 0) {
          try { process.kill(owner.pid!, 0); } catch (probe) {
            if ((probe as NodeJS.ErrnoException).code === "ESRCH") await rm(file, { force: true });
          }
        }
      } catch { /* writer/reclaimer may be filling its lock; bounded retry */ }
      finally { if (reclaimer) { await reclaimer.close(); await rm(reclaimPath, { force: true }); } }
      if (Date.now() >= deadline) throw new Error("Checkpoint lock busy; retry after the other writer finishes");
      await new Promise(resolve => setTimeout(resolve, 20));
    }
  }
  try { return await operation(); } finally { await lock.close(); await rm(file, { force: true }); }
}

function render(snapshot: Snapshot): Record<string, string> {
  const d = snapshot.data;
  const section = (title: string, values: string[]) => [`## ${title}`, ...(values.length ? values.map(v => `- ${v}`) : ["- None recorded."]), ""].join("\n");
  const common = [
    section("Accepted decisions", d.decisions), section("Rejected / superseded", d.rejected),
    section("Constraints", d.constraints), section("Open issues", d.openIssues),
    section("Next", d.next), section("Verification", d.verification), section("Files materially touched", d.files),
  ].join("\n");
  const header = `Updated: ${snapshot.updatedAt}\nRevision: ${snapshot.revision}\nEvent: ${d.eventType}\nVerification recorded: ${snapshot.verificationEvidence?.recordedAt ?? "unknown; retained legacy evidence is not tied to the current tree"}\n`;
  const state = `# Session Checkpoint\n\n${header}\n## Current state\n${d.summary}\n\n## Objective\n${d.objective || "Not explicitly recorded."}\n\n## User intent / rationale\n${d.intent || "Not explicitly recorded."}\n\n${common}\n## Authority note\nCurrent code/Git establishes implementation facts. User requirements and prohibitions remain normative constraints.\n`;
  const handoff = `# Handoff\n\n${header}\n## Resume objective\n${d.objective || d.summary}\n\n## Why this work is being done\n${d.intent || "Not explicitly recorded."}\n\n## What is true now\n${d.summary}\n\n${common}`;
  const baseline = snapshot.baseline.supported ? { version: 1, checkpointAt: snapshot.updatedAt, ...snapshot.baseline } : { version: 1, supported: false, checkpointAt: snapshot.updatedAt };
  return { "SESSION_CHECKPOINT.md": state, "HANDOFF.md": handoff, "STATE.json": JSON.stringify(baseline, null, 2) + "\n",
    "SNAPSHOT.json": JSON.stringify(snapshot, null, 2) + "\n" };
}

export type CheckpointInspection = {
  snapshot: Snapshot | null;
  integrity: { coherent: boolean; driftPaths: string[]; repairPaths: string[]; warning: string | null };
};

// No mkdir, lock, repair, or write on the read path. A complete journal event is
// the commit point; an independently edited snapshot cannot supersede it.
export async function inspectCheckpoint(root: string): Promise<CheckpointInspection> {
  const dir = path.join(root, ".context");
  const current = parseSnapshot(await optionalText(path.join(dir, "SNAPSHOT.json")));
  const snapshot = await latestEvent(dir) ?? current;
  const driftPaths: string[] = [], repairPaths: string[] = [];
  if (snapshot) {
    const oldViews = current && current.revision < snapshot.revision ? render(current) : {};
    for (const [name, expected] of Object.entries(render(snapshot))) {
      const actual = await optionalText(path.join(dir, name));
      if (actual === expected) continue;
      const relative = `.context/${name}`;
      if (actual === null || actual === oldViews[name]) repairPaths.push(relative);
      else driftPaths.push(relative);
    }
  }
  return { snapshot, integrity: {
    coherent: driftPaths.length === 0 && repairPaths.length === 0, driftPaths, repairPaths,
    warning: driftPaths.length ? "External projection edits detected. Read and reconcile them at this revision before checkpointing; canonical state does not include these edits."
      : repairPaths.length ? "Committed state was recovered in memory; projections need repair on the next authorized checkpoint." : null,
  } };
}

export async function readCheckpoint(root: string): Promise<Snapshot | null> {
  return (await inspectCheckpoint(root)).snapshot;
}

async function legacyData(dir: string): Promise<Partial<CheckpointData>> {
  const raw = await optionalText(path.join(dir, "SESSION_CHECKPOINT.md"));
  if (!raw) return {};
  const sections = new Map<string, string>();
  for (const part of raw.split(/^## /m).slice(1)) {
    const end = part.indexOf("\n"); sections.set(part.slice(0, end).trim(), part.slice(end + 1).trim());
  }
  const scalar = (key: string) => { const value = sections.get(key); return value && value !== "Not explicitly recorded." ? value : undefined; };
  const array = (key: string) => (sections.get(key) ?? "").split("\n").filter(line => /^- /.test(line) && !/^- (?:None recorded\.|No .* recorded\.)$/.test(line)).map(line => line.slice(2));
  return { objective: scalar("Objective"), intent: scalar("User intent / rationale"), decisions: array("Accepted decisions"),
    rejected: array("Rejected / superseded"), constraints: array("Constraints"), openIssues: array("Open issues"),
    next: array("Next"), verification: array("Verification"), files: array("Files materially touched") };
}

function merged(previous: Partial<CheckpointData>, input: CheckpointData): CheckpointData {
  const d: CheckpointData = { summary: input.summary.trim(), eventType: input.eventType,
    objective: input.objective ?? previous.objective, intent: input.intent ?? previous.intent,
    decisions: [], rejected: [], constraints: [], openIssues: [], next: [], files: [], verification: [] };
  for (const key of lists) {
    const replace = input.replaceFields?.includes(key) || (["next", "files", "verification"].includes(key) && input[key].length > 0);
    d[key] = [...new Set([...(replace ? [] : previous[key] ?? []), ...input[key]].map(value => value.trim()).filter(Boolean))];
  }
  for (const field of input.clearFields ?? []) {
    if (field === "objective" || field === "intent") delete d[field]; else d[field] = [];
  }
  return d;
}

export async function commitCheckpoint(root: string, input: CheckpointData, fingerprint: () => Promise<Baseline>): Promise<Record<string, unknown>> {
  if (!input.summary.trim()) throw new Error("Checkpoint summary must not be empty");
  const dir = path.join(root, ".context");
  return withContextLock(dir, async () => {
    const inspected = await inspectCheckpoint(root);
    const previous = inspected.snapshot;
    if (input.reconcileProjection && input.baseRevision === undefined) throw new Error("Projection reconciliation requires an explicit baseRevision");
    if (inspected.integrity.driftPaths.length && !input.reconcileProjection) {
      throw new Error(`Context projection drift: ${inspected.integrity.driftPaths.join(", ")}; read these files and reconcile with baseRevision and reconcileProjection=true before retry`);
    }
    const { baseRevision: _base, eventId: _id, ...payload } = input;
    const signature = createHash("sha256").update(JSON.stringify(payload)).digest("hex");
    const eventId = input.eventId ?? randomUUID();
    let known = previous && Object.hasOwn(previous.eventIds, eventId) ? previous.eventIds[eventId] : undefined;
    if (!known && input.eventId) {
      const history = await optionalText(path.join(dir, "CONVERSATION.jsonl"));
      for (const line of (history ?? "").split("\n")) {
        try { const event = JSON.parse(line) as { eventId?: string; signature?: string }; if (event.eventId === eventId) known = event.signature; } catch { /* legacy or interrupted record */ }
      }
    }
    if (known) {
      if (known !== signature) throw new Error("eventId already used for a different checkpoint payload");
      // A retry after a committed crash may repair known stale views, but never
      // silently replaces externally edited projections.
      if (previous) for (const [name, text] of Object.entries(render(previous))) await atomicText(path.join(dir, name), text);
      return { root, revision: previous?.revision ?? 0, eventId, duplicate: true };
    }
    const revision = previous?.revision ?? 0;
    if (input.baseRevision !== undefined && input.baseRevision !== revision) throw new Error(`Checkpoint revision conflict: expected ${input.baseRevision}, current ${revision}; bootstrap and reconcile before retry`);
    const snapshot: Snapshot = { version: 2, revision: revision + 1, updatedAt: new Date().toISOString(),
      data: merged(previous?.data ?? await legacyData(dir), input), baseline: await fingerprint(),
      eventIds: Object.fromEntries([...Object.entries(previous?.eventIds ?? {}), [eventId, signature]].slice(-256)) };
    snapshot.verificationEvidence = input.clearFields?.includes("verification") ? null
      : input.verification.length ? { recordedAt: snapshot.updatedAt, revision: snapshot.revision, fingerprint: snapshot.baseline.fingerprint ?? null }
      : previous?.verificationEvidence ?? null;
    if (input.captureToken) snapshot.captureEvidence = { token: input.captureToken, revision: snapshot.revision };
    const event = { time: snapshot.updatedAt, eventId, signature, revision: snapshot.revision, eventType: input.eventType,
      summary: input.summary, objective: snapshot.data.objective ?? null, intent: snapshot.data.intent ?? null,
      accepted: snapshot.data.decisions, rejected: snapshot.data.rejected, constraints: snapshot.data.constraints,
      openIssues: snapshot.data.openIssues, next: snapshot.data.next, snapshot };
    const line = JSON.stringify(event) + "\n";
    if (Buffer.byteLength(line) > maxEventBytes) throw new Error("Checkpoint exceeds 128KiB; resolve or replace inactive fields explicitly before retry");
    const staged: Array<[string, string]> = [];
    let committed = false;
    try {
      // All writes are prepared before the commit point. A preparation failure
      // leaves every published file and history entry intact.
      for (const [name, text] of Object.entries(render(snapshot))) {
        const target = path.join(dir, name);
        const temp = `${target}.${randomUUID()}.tmp`;
        staged.push([temp, target]);
        await writeFile(temp, text, "utf8");
        const handle = await open(temp, "r"); try { await handle.sync(); } finally { await handle.close(); }
      }
      const log = await open(path.join(dir, "CONVERSATION.jsonl"), "a+");
      try {
        const size = (await log.stat()).size;
        // Preserve incomplete records as invalid history and isolate the new line.
        if (size) { const last = Buffer.alloc(1); await log.read(last, 0, 1, size - 1); if (last[0] !== 10) await log.write("\n"); }
        await log.write(line); await log.sync(); committed = true;
      } finally { await log.close(); }
      for (const [temp, target] of staged) await rename(temp, target);
    } catch (error) {
      if (!committed) throw error;
      // Once the event is durable, report success with an explicit recovery flag.
      // Reads recover in memory; an authorized checkpoint retry repairs views.
      return { root, revision: snapshot.revision, eventId, committed: true, recoveryRequired: true,
        warning: error instanceof Error ? error.message : String(error) };
    } finally { for (const [temp] of staged) await rm(temp, { force: true }); }
    // Compatibility history views; the semantic journal remains canonical.
    let warning: string | undefined;
    try {
      const log = await open(path.join(dir, "WORKLOG.jsonl"), "a");
      try { await log.write(JSON.stringify({ time: snapshot.updatedAt, root, eventId, revision: snapshot.revision, ...input }) + "\n"); } finally { await log.close(); }
      if (input.decisions.length) {
        const decisions = await open(path.join(dir, "DECISIONS.md"), "a");
        try { await decisions.write(`\n## ${snapshot.updatedAt}\n${input.decisions.map(v => `- ${v}`).join("\n")}\n`); } finally { await decisions.close(); }
      }
    } catch (error) { warning = `Compatibility history view requires attention: ${String(error)}`; }
    return { root, revision: snapshot.revision, eventId, checkpoint: ".context/SESSION_CHECKPOINT.md", handoff: ".context/HANDOFF.md",
      conversation: ".context/CONVERSATION.jsonl", worklog: ".context/WORKLOG.jsonl", decisions: input.decisions.length ? ".context/DECISIONS.md" : null,
      continuityState: ".context/STATE.json", workingTreeFingerprint: snapshot.baseline.fingerprint ?? null, ...(warning ? { warning } : {}) };
  });
}
