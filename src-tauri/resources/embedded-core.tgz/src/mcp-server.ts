import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";

import type { AppConfig } from "./config.js";
import { registerBrowserTools } from "./browser-tools.js";
import { PROJECT_CONTEXT_POLICY, registerContextTools } from "./context-tools.js";
import { registerExecTools } from "./exec-tools.js";
import { ContextGuard } from "./context-guard.js";
import { FileService } from "./file-service.js";
import { registerFileTools } from "./file-tools.js";
import { ProcessManager } from "./process-manager.js";

export interface McpServices {
  processManager: ProcessManager;
  contextGuard: ContextGuard;
  fileService: FileService;
}

export function createServices(config: AppConfig): McpServices {
  return {
    contextGuard: new ContextGuard(),
    processManager: new ProcessManager({
      maxRetainedOutputBytes: config.maxRetainedProcessOutputBytes,
      processRetentionMs: config.processRetentionMs,
      maxProcesses: config.maxProcesses,
      defaultMaxOutputBytes: config.maxOutputBytes,
    }),
    fileService: new FileService({
      defaultCwd: config.defaultCwd,
      maxChunkBytes: config.maxFileChunkBytes,
      maxEditFileBytes: config.maxEditFileBytes,
      maxOutputBytes: config.maxOutputBytes,
    }),
  };
}

export function createMcpServer(config: AppConfig, services: McpServices): McpServer {
  const server = new McpServer(
    {
      name: "cokacremote",
      version: "0.1.0",
    },
    {
      instructions:
        "This server is an unrestricted remote development environment. Tools operate directly on the host with the MCP service process's full OS permissions. Use exec_command for shell, build, test, package, Git, service, and log workflows; run_script for complete Bash, Node.js, or Python scripts; the file tools for direct file operations; and browse_and_execute for web scraping, page navigation, DOM interaction, or browser automation tasks. Poll long-running commands with read_process or write_stdin. " +
        "At a local-project/session boundary, and whenever the user asks to continue/resume prior project work, you MUST call project_context_bootstrap before editing or making project decisions. Mutation tools require the returned contextHandle; a missing/expired handle returns CONTEXT_REQUIRED before executing. Handles are scoped to the resolved project, independent of transport session, and reset when this server restarts. Use a new bootstrap after resume/clear/compaction and do not share handles with another conversation. Retry a CONTEXT_REQUIRED action once after recovery; if it still fails, report the scope/handle mismatch instead of looping. Use project_context_recall only when fast bootstrap is insufficient. During work, call project_context_checkpoint after material changes AND after meaningful conversation events such as approvals/rejections, durable decisions, reversals, new constraints, blockers, milestones, or handoff; do not wait for session end. " +
        PROJECT_CONTEXT_POLICY,
      capabilities: { logging: {} },
    },
  );

  registerExecTools(
    server,
    config,
    services.processManager,
    services.fileService,
    services.contextGuard,
  );
  registerFileTools(server, config, services.fileService, services.contextGuard);
  registerContextTools(server, config, services.contextGuard);
  if (config.enableBrowserTools) {
    registerBrowserTools(server, config);
  }
  return server;
}
