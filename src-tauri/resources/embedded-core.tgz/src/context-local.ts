import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { collectDocs, resolveProjectRoot, workingTreeFingerprint } from './context-tools.js';
import { inspectCheckpoint, withContextLock } from './context-store.js';

export type ContextClient = 'codex' | 'claude' | 'cursor' | 'gemini';
export const localContextRuntime = () => process.env.AGENT_CONTEXT_RUNTIME_DIR || path.join(os.homedir(), '.config/agent-context/runtime');
const hash = (s: string) => createHash('sha256').update(s).digest('hex');
export const ackPath = (root: string, token: string) => path.join(root, '.context/acks', `${hash(token)}.json`);
async function json<T>(file: string): Promise<T | null> {
  try { return JSON.parse(await readFile(file, 'utf8')) as T; } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null;
    throw error;
  }
}
async function save(file: string, value: unknown) {
  await mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${randomUUID()}.tmp`;
  try { await writeFile(temporary, JSON.stringify(value) + '\n', { mode: 0o600 }); await rename(temporary, file); }
  finally { await rm(temporary, { force: true }); }
}
export async function localCapsule(inputPath: string) {
  const root = await resolveProjectRoot(inputPath);
  const [inspection, current, docs] = await Promise.all([inspectCheckpoint(root), workingTreeFingerprint(root), collectDocs(root, inputPath)]);
  const state = inspection.snapshot;
  const capsule: Record<string, unknown> = {
    root, revision: state?.revision ?? 0,
    freshness: current.fingerprint && state?.baseline.fingerprint ? current.fingerprint === state.baseline.fingerprint ? 'unchanged' : 'changed' : 'unknown',
    integrity: inspection.integrity, checkpoint: state?.data ?? null,
    verificationFreshness: current.fingerprint && state?.verificationEvidence?.fingerprint ? current.fingerprint === state.verificationEvidence.fingerprint ? 'unchanged' : 'changed' : 'unknown',
    documents: docs.map(doc => ({ path: doc.path, fullReadRequired: true })),
    policy: 'Current code/Git establishes observed implementation; current user requirements remain binding. Read relevant project instructions and CURRENT contracts before material work. Historical memory is reference only. Never silently merge conflicts or invent verified state. Use deep historical retrieval only when needed. Local recovery does not grant an MCP execution contextHandle.',
  };
  // Explicit detail requirement, not an assertion that a truncated prohibition
  // set is complete. Byte cap is a proxy; actual tokens are measured in trials.
  if (Buffer.byteLength(JSON.stringify(capsule)) > 8000) {
    capsule.checkpoint = state ? { objective: state.data.objective?.slice(0, 600), intent: state.data.intent?.slice(0, 600), summary: state.data.summary.slice(0, 600), needsDetail: true,
      requiredRead: '.context/SNAPSHOT.json', reason: 'Read full committed semantic state before relying on decisions/prohibitions; this capsule is incomplete.' } : null;
  }
  if (Buffer.byteLength(JSON.stringify(capsule)) > 10000) throw new Error('Context navigation metadata exceeds budget; inspect project instructions and committed state locally');
  return { root, capsule, inspection, current };
}

type Pending = { token: string; prompt: string; truncated: boolean; startingRevision: number; fingerprint: string | null; continued: boolean };
type Session = { root: string; client: ContextClient; key: string; updatedAt: number; pending?: Pending; injected?: string };
const startEvents = new Set(['SessionStart', 'sessionStart']);
const promptEvents = new Set(['UserPromptSubmit', 'beforeSubmitPrompt', 'BeforeAgent']);
const stopEvents = new Set(['Stop', 'stop', 'AfterAgent']);
const continuationMarker = '[CONTEXT_CHECKPOINT_REQUIRED]';
function contextOutput(client: ContextClient, event: string, text: string) {
  return client === 'cursor' ? { additional_context: text } : { hookSpecificOutput: { hookEventName: event, additionalContext: text } };
}
function stopOutput(client: ContextClient, reason: string) {
  if (client === 'cursor') return { followup_message: reason };
  if (client === 'gemini') return { decision: 'deny', reason };
  return { decision: 'block', reason };
}

export async function handleContextHook(client: ContextClient, input: Record<string, unknown>, cliCommand: string, runtime = localContextRuntime()) {
  const identity = String(input.session_id || input.conversation_id || '');
  if (!identity) throw new Error('Lifecycle input must identify the conversation');
  // Cursor SessionStart is asynchronous. Serialize its state update with the
  // first submitted prompt using the already existing lock owner.
  return withContextLock(path.join(runtime, '.locks', hash(`${client}:${identity}`)), () => runContextHook(client, input, cliCommand, runtime));
}

async function runContextHook(client: ContextClient, input: Record<string, unknown>, cliCommand: string, runtime: string) {
  const event = String(input.hook_event_name || input.hookEventName || '');
  const projectInput = String((Array.isArray(input.workspace_roots) ? input.workspace_roots[0] : '') ||
    (client === 'cursor' ? process.env.CURSOR_PROJECT_DIR : '') || input.cwd ||
    (client === 'gemini' ? process.env.GEMINI_PROJECT_DIR : process.env.CLAUDE_PROJECT_DIR) || '');
  if (!projectInput || !path.isAbsolute(projectInput)) throw new Error('Lifecycle input must identify an absolute project path; process cwd is not a safe fallback');
  const root = await resolveProjectRoot(projectInput);
  const key = hash(`${client}:${String(input.session_id || input.conversation_id || '')}:${root}`);
  const file = path.join(runtime, `${key}.json`);
  const existing = await json<Session>(file);
  const session: Session = existing ?? { root, client, key, updatedAt: Date.now() };
  let output: Record<string, unknown> = {};
  if (startEvents.has(event) || promptEvents.has(event)) {
    const prompt = String(input.prompt || input.user_prompt || '');
    // Stop continuation is a new prompt in Codex. Keep the original event token
    // so the extra pass cannot accidentally acknowledge itself instead.
    if (promptEvents.has(event) && !prompt.startsWith(continuationMarker)) {
      if (session.pending) {
        // An interruption followed by a new turn must not replace the previous
        // uncommitted decision input. Retain a bounded raw input separately.
        await save(path.join(runtime, `${key}.${hash(session.pending.token).slice(0, 20)}.json`), session);
      }
      const local = await localCapsule(projectInput);
      session.pending = { token: `hook:${client}:${key.slice(0, 20)}:${hash(String(input.turn_id || randomUUID())).slice(0, 20)}`,
        prompt: prompt.slice(0, 6000), truncated: prompt.length > 6000, startingRevision: local.inspection.snapshot?.revision ?? 0,
        fingerprint: local.current.fingerprint ?? null, continued: false };
    }
    const local = await localCapsule(projectInput);
    const signature = hash(JSON.stringify(local.capsule));
    let text = startEvents.has(event) || session.injected !== signature ? `PROJECT_CONTEXT\n${JSON.stringify(local.capsule)}\n` : '';
    session.injected = signature;
    if (startEvents.has(event)) {
      const pending: Array<{ token: string; prompt: string; truncated: boolean }> = [];
      for (const name of (await readdir(runtime).catch(() => [] as string[])).filter(s => s.endsWith('.json')).slice(0, 100)) {
        const prior = await json<Session>(path.join(runtime, name));
        if (prior?.root === root && prior.pending) pending.push({ token: prior.pending.token, prompt: prior.pending.prompt, truncated: prior.pending.truncated });
      }
      if (pending.length) text += `UNCOMMITTED_INPUT (not accepted decisions; reconcile explicitly; ${pending.length} retained inputs, showing at most 3): ${JSON.stringify(pending.slice(-3).map(p => ({ ...p, prompt: p.prompt.slice(0, 1000), truncated: p.truncated || p.prompt.length > 1000 })))}\n`;
    }
    if (session.pending) text += `Context event token: ${session.pending.token}; baseRevision: ${local.inspection.snapshot?.revision ?? 0}.\n`;
    text += `After a meaningful decision/reversal/constraint/milestone or material change, use the CURRENT working model to write a semantic checkpoint through ${cliCommand} checkpoint --path ${JSON.stringify(root)} with JSON stdin (summary, objective/intent, decisions/rejected/constraints/next, only verified state, baseRevision, captureToken). Omitted lists preserve prior entries; explicitly replace/clear superseded state. Do not directly edit generated .context markdown/snapshot or use an older context writer. If this turn is trivial with no durable state change, use ${cliCommand} ack --path ${JSON.stringify(root)} --capture-token ${session.pending?.token || '<event-token>'} with JSON stdin {"reason":"why no meaningful state changed"}. Do not introduce another model or copy full transcripts.\n`;
    output = contextOutput(client, event, text);
  } else if (stopEvents.has(event) && session.pending) {
    const inspected = await inspectCheckpoint(root);
    const snapshot = inspected.snapshot;
    const current = await workingTreeFingerprint(root);
    const ack = await json<{ token: string; fingerprint: string | null; reason: string }>(ackPath(root, session.pending.token));
    const integrityOK = inspected.integrity.coherent;
    const captured = integrityOK && snapshot?.captureEvidence?.token === session.pending.token && snapshot.baseline.fingerprint === current.fingerprint;
    const acknowledged = integrityOK && ack?.token === session.pending.token && ack.fingerprint === current.fingerprint && session.pending.fingerprint === current.fingerprint;
    if (captured || acknowledged) {
      if (acknowledged) await rm(ackPath(root, session.pending.token), { force: true });
      delete session.pending;
    } else if (!session.pending.continued && input.stop_hook_active !== true && Number(input.loop_count || 0) < 1) {
      session.pending.continued = true;
      output = stopOutput(client, `${continuationMarker} Persist the original turn's meaningful semantic state using ${cliCommand} checkpoint --path ${JSON.stringify(root)}, baseRevision=${snapshot?.revision ?? 0}, captureToken=${session.pending.token}. Read/reconcile any projection drift explicitly. If no durable state changed, acknowledge it with ${cliCommand} ack and a reason. Preserve the original user response after recording. This is one bounded completion pass; no extra agent/model.`);
    } else {
      output = { systemMessage: 'Context persistence remains unconfirmed after the bounded completion pass. Pending input is retained; do not claim continuity is complete.' };
    }
  } else if (event === 'PreToolUse' || event === 'preToolUse' || event === 'BeforeTool') {
    const tool = String(input.tool_name || '');
    if (/cokacremote.*project_context_checkpoint/.test(tool)) {
      const reason = `Use the shared local checkpoint writer (${cliCommand}) for this lifecycle event; the older hosted writer may not preserve canonical state.`;
      output = client === 'cursor' ? { permission: 'deny', agent_message: reason } : client === 'gemini' ? { decision: 'deny', reason }
        : { hookSpecificOutput: { hookEventName: event, permissionDecision: 'deny', permissionDecisionReason: reason } };
    }
  }
  session.updatedAt = Date.now();
  await save(file, session);
  if (process.env.AGENT_CONTEXT_TRACE) {
    const trace = process.env.AGENT_CONTEXT_TRACE;
    const { appendFile } = await import('node:fs/promises');
    await mkdir(path.dirname(trace), { recursive: true });
    await appendFile(trace, JSON.stringify({ time: new Date().toISOString(), client, event, root, token: session.pending?.token ?? null,
      pending: Boolean(session.pending), continued: session.pending?.continued ?? false, output, sessionKey: key }) + '\n');
  }
  return output;
}
