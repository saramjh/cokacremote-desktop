import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { access, open, readFile, realpath, readdir, stat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { performance } from "node:perf_hooks";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import * as z from "zod/v4";

import type { AppConfig } from "./config.js";
import { runTool } from "./tool-result.js";
import { commitCheckpoint, inspectCheckpoint, type CheckpointData } from "./context-store.js";
import type { ContextGuard } from "./context-guard.js";
import { TOOL_ANNOTATIONS, toolAuthMetadata } from "./tool-metadata.js";

export const CHECKPOINT_INPUT = {
        path: z.string().optional().describe("Project path or any path inside it. Defaults to the server working directory."),
        eventId: z.string().min(1).max(200).optional().describe("Stable ID for retrying one event without duplicate publication."),
        baseRevision: z.number().int().optional().describe("Revision from bootstrap/checkpoint; rejects stale writers."),
        reconcileProjection: z.boolean().default(false).describe("Explicitly reconcile externally edited projections after reading them; requires baseRevision and the reconciled semantic fields."),
        captureToken: z.string().min(1).max(200).optional().describe("Token supplied by the global lifecycle adapter for the current conversation event."),
        clearFields: z.array(z.enum(["objective", "intent", "decisions", "rejected", "constraints", "openIssues", "next", "files", "verification"])).default([]).describe("Explicitly clear these fields; omitted fields are preserved."),
        replaceFields: z.array(z.enum(["decisions", "rejected", "constraints", "openIssues", "next", "files", "verification"])).default([]).describe("Replace these lists rather than adding entries; history remains in the event log."),
        eventType: z
          .enum(["decision", "constraint", "milestone", "implementation", "blocker", "handoff", "other"])
          .default("implementation")
          .describe("Why this rolling checkpoint is being written."),
        summary: z.string().trim().min(1).describe("Concise current-state summary based on verified work and conversation state, not guesses."),
        objective: z.string().optional().describe("Current project/task objective that a new session must continue."),
        intent: z.string().optional().describe("User rationale or desired outcome that may not be visible in code."),
        decisions: z.array(z.string()).default([]).describe("New accepted durable decisions."),
        rejected: z.array(z.string()).default([]).describe("Rejected or superseded approaches and, where useful, why they were rejected."),
        constraints: z.array(z.string()).default([]).describe("Important requirements, prohibitions, or guardrails a new session must preserve."),
        openIssues: z.array(z.string()).default([]).describe("Known unresolved issues or uncertainties."),
        next: z.array(z.string()).default([]).describe("Concrete next actions or unresolved blockers."),
        files: z.array(z.string()).default([]).describe("Materially touched files or areas."),
        verification: z.array(z.string()).default([]).describe("Tests/checks actually run and their verified outcomes."),
      };

const POLICY = [
  "Project context authority (highest to lowest):",
  "1) current executable code, runtime state, database/schema, and Git working tree;",
  "2) explicit current-state/source-of-truth/checkpoint/handoff documents in the repository;",
  "3) accepted decision/architecture/product contracts;",
  "4) Serena project memories;",
  "5) claude-mem historical/session memory;",
  "6) old chat/transcript recollection.",
  "Current code establishes observed implementation, not permission to override current user requirements/prohibitions. Report implementation-contract conflicts explicitly.",
  "Never let lower-authority or older memory override higher-authority current evidence.",
  "Treat Serena/claude-mem as retrieval aids, not truth stores. Mark conflicts and prefer the higher-authority source.",
  "Headroom is compression/retrieval only and is never a source of truth.",
  "Ponytail is implementation policy (YAGNI/reuse/native-first), not a memory source.",
  "Do not invent missing project state. If evidence conflicts or is absent, say so and inspect the repository.",
  "Use fast bootstrap at a project/session boundary. Use deep recall only when fast context is insufficient.",
  "Persist a rolling checkpoint after meaningful decisions, reversals, new constraints, milestones, or material changes; do not wait for session end.",
  "At bootstrap, compare the current Git working-tree fingerprint with the last checkpoint baseline; if they differ, treat the checkpoint as stale and re-verify current code/Git before handoff.",
].join("\n");

type McpSpec = { command: string; args: string[] };

type WorkingTreeFingerprint = {
  supported: boolean;
  gitRoot?: string;
  head?: string;
  fingerprint?: string;
  changedPaths: string[];
  error?: string;
};

type ContinuityState = {
  version: 1;
  checkpointAt: string;
  gitRoot: string;
  head: string;
  fingerprint: string;
  changedPaths: string[];
};

function envRecord(): Record<string, string> {
  return Object.fromEntries(
    Object.entries(process.env).filter((entry): entry is [string, string] => typeof entry[1] === "string"),
  );
}

function toolText(result: unknown): string {
  if (!result || typeof result !== "object") return "";
  const content = (result as { content?: unknown[] }).content;
  if (!Array.isArray(content)) return "";
  return content
    .filter((item): item is { type: "text"; text: string } =>
      Boolean(
        item &&
        typeof item === "object" &&
        (item as { type?: unknown }).type === "text" &&
        typeof (item as { text?: unknown }).text === "string",
      ),
    )
    .map((item) => item.text)
    .join("\n");
}

async function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms} ms`)), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function withMcpClient<T>(
  spec: McpSpec,
  cwd: string,
  operation: (client: Client) => Promise<T>,
  timeoutMs = 12_000,
): Promise<T> {
  const transport = new StdioClientTransport({
    ...spec,
    cwd,
    env: envRecord(),
    stderr: "pipe",
  });
  const client = new Client({ name: "cokacremote-context", version: "0.2.0" });
  try {
    await withTimeout(client.connect(transport), timeoutMs, "mcp:connect");
    return await operation(client);
  } finally {
    try {
      await transport.close();
    } catch {
      // Best-effort child cleanup.
    }
  }
}

async function callMcp(
  spec: McpSpec,
  cwd: string,
  toolName: string,
  args: Record<string, unknown>,
  timeoutMs = 12_000,
): Promise<{ ok: boolean; text?: string; structuredContent?: unknown; error?: string }> {
  try {
    return await withMcpClient(
      spec,
      cwd,
      async (client) => {
        const result = await withTimeout(
          client.callTool({ name: toolName, arguments: args }),
          timeoutMs,
          toolName,
        );
        return {
          ok: !(result as { isError?: boolean }).isError,
          text: toolText(result),
          structuredContent: (result as { structuredContent?: unknown }).structuredContent,
        };
      },
      timeoutMs,
    );
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

function git(cwd: string, args: string[], maxBuffer = 64 * 1024): string | null {
  const result = spawnSync("git", args, {
    cwd,
    encoding: "utf8",
    timeout: 5_000,
    maxBuffer,
  });
  if (result.status !== 0) return null;
  return result.stdout.trimEnd();
}

function gitBuffer(cwd: string, args: string[], maxBuffer = 16 * 1024 * 1024): Buffer | null {
  const result = spawnSync("git", args, {
    cwd,
    encoding: null,
    timeout: 10_000,
    maxBuffer,
  });
  if (result.status !== 0 || !Buffer.isBuffer(result.stdout)) return null;
  return result.stdout;
}

function isContextInternalPath(file: string): boolean {
  return (
    file === ".context" ||
    file.startsWith(".context/") ||
    file === ".serena" ||
    file.startsWith(".serena/")
  );
}

export async function workingTreeFingerprint(root: string): Promise<WorkingTreeFingerprint> {
  const gitRoot = git(root, ["rev-parse", "--show-toplevel"]);
  if (!gitRoot) {
    return {
      supported: false,
      changedPaths: [],
      error: "not a Git work tree",
    };
  }

  const head = git(gitRoot, ["rev-parse", "--verify", "HEAD"]) ?? "NO_HEAD";
  const excludedPathspec = [".", ":(exclude).context/**", ":(exclude).serena/**"];

  // Hash the index and working tree separately: HEAD=A, index=B, worktree=A
  // must not collapse to a clean HEAD-to-worktree diff.
  const staged = gitBuffer(gitRoot, ["diff", "--binary", "--no-ext-diff", "--cached", "--", ...excludedPathspec]);
  const unstaged = gitBuffer(gitRoot, ["diff", "--binary", "--no-ext-diff", "--", ...excludedPathspec]);
  const diff = staged && unstaged ? Buffer.concat([staged, Buffer.from("\0"), unstaged]) : null;
  const branch = git(gitRoot, ["symbolic-ref", "--quiet", "HEAD"]) || "DETACHED";

  if (!diff) {
    return {
      supported: false,
      gitRoot,
      head,
      changedPaths: [],
      error: "failed to compute Git diff",
    };
  }

  const untrackedRaw = gitBuffer(gitRoot, ["ls-files", "--others", "--exclude-standard", "-z"]);
  if (!untrackedRaw) {
    return {
      supported: false,
      gitRoot,
      head,
      changedPaths: [],
      error: "failed to enumerate untracked files",
    };
  }

  const untracked = untrackedRaw
    .toString("utf8")
    .split("\0")
    .filter(Boolean)
    .filter((file) => !isContextInternalPath(file))
    .sort();

  const hasher = createHash("sha256");
  hasher.update("cokacremote-context-fingerprint-v2\0");
  hasher.update(gitRoot);
  hasher.update("\0");
  hasher.update(branch);
  hasher.update("\0");
  hasher.update(head);
  hasher.update("\0");
  hasher.update(diff);

  for (const file of untracked) {
    const objectHash = git(gitRoot, ["hash-object", "--", file]);
    if (!objectHash) return { supported: false, gitRoot, head, changedPaths: [], error: `Cannot hash untracked file: ${file}` };
    hasher.update("\0untracked\0");
    hasher.update(file);
    hasher.update("\0");
    hasher.update(objectHash);
  }

  const status = git(gitRoot, ["status", "--short", "--untracked-files=all"], 512 * 1024) ?? "";
  const changedPaths = status
    .split("\n")
    .filter(Boolean)
    .filter((line) => {
      const file = line.slice(3).trim().replace(/^"|"$/g, "");
      const destination = file.includes(" -> ") ? file.split(" -> ").at(-1) ?? file : file;
      return !isContextInternalPath(destination);
    })
    .slice(0, 200);

  return {
    supported: true,
    gitRoot,
    head,
    fingerprint: hasher.digest("hex"),
    changedPaths,
  };
}

async function readContinuityState(root: string): Promise<ContinuityState | null> {
  try {
    const raw = await readFile(path.join(root, ".context", "STATE.json"), "utf8");
    const parsed = JSON.parse(raw) as Partial<ContinuityState>;
    if (
      parsed.version === 1 &&
      typeof parsed.checkpointAt === "string" &&
      typeof parsed.gitRoot === "string" &&
      typeof parsed.head === "string" &&
      typeof parsed.fingerprint === "string" &&
      Array.isArray(parsed.changedPaths)
    ) {
      return parsed as ContinuityState;
    }
  } catch {
    // Missing or malformed state means there is no trusted checkpoint fingerprint yet.
  }
  return null;
}

async function continuityStatus(root: string): Promise<Record<string, unknown>> {
  const [baseline, current] = await Promise.all([
    readContinuityState(root),
    workingTreeFingerprint(root),
  ]);

  if (!current.supported) {
    return {
      supported: false,
      dirtySinceCheckpoint: null,
      freshness: "unknown",
      warning: current.error ?? "working-tree fingerprint unavailable",
    };
  }

  if (!baseline) {
    return {
      supported: true,
      baselineAvailable: false,
      dirtySinceCheckpoint: null,
      freshness: "unknown",
      currentHead: current.head,
      currentChangedPaths: current.changedPaths,
      warning:
        "No checkpoint fingerprint baseline exists yet. Context continuity cannot prove whether current working-tree changes were checkpointed; write project_context_checkpoint after meaningful work.",
    };
  }

  const dirtySinceCheckpoint = baseline.fingerprint !== current.fingerprint;
  return {
    supported: true,
    baselineAvailable: true,
    dirtySinceCheckpoint,
    freshness: dirtySinceCheckpoint ? "changed" : "unchanged",
    currentFingerprint: current.fingerprint,
    checkpointAt: baseline.checkpointAt,
    checkpointHead: baseline.head,
    currentHead: current.head,
    checkpointChangedPaths: baseline.changedPaths,
    currentChangedPaths: current.changedPaths,
    warning: dirtySinceCheckpoint
      ? "Working-tree state changed after the last project context checkpoint. Re-verify current code/Git state and write a new project_context_checkpoint before handoff."
      : null,
  };
}

export async function resolveProjectRoot(input: string): Promise<string> {
  let existing = path.resolve(input.replace(/^~(?=\/|$)/, os.homedir()));
  while (true) {
    try {
      const resolved = await realpath(existing);
      const info = await stat(resolved);
      const cwd = info.isDirectory() ? resolved : path.dirname(resolved);
      return git(cwd, ["rev-parse", "--show-toplevel"]) || cwd;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      const parent = path.dirname(existing);
      if (parent === existing) throw error;
      existing = parent;
    }
  }
}

const DOC_NAMES = new Set([
  "AGENTS.md",
  "CLAUDE.md",
  "GEMINI.md",
  "PROJECT_CONSTITUTION.md",
  "PRODUCT.md",
  "DESIGN.md",
  "ARCHITECTURE.md",
  "DECISIONS.md",
  "CURRENT.md",
  "CURRENT_STATE.md",
  "CURRENT_CHECKPOINT.md",
  "CURRENT_IMPLEMENTATION_SOURCE_OF_TRUTH.md",
  "SESSION_CHECKPOINT.md",
  "HANDOFF.md",
  "README.md",
]);

function documentPriority(file: string): number {
  const name = path.basename(file).toUpperCase();
  if (name === "HANDOFF.MD") return 102;
  if (
    name.includes("SESSION_CHECKPOINT") ||
    name === "CURRENT.MD" ||
    name.includes("CURRENT_STATE") ||
    name.includes("CURRENT_CHECKPOINT")
  ) return 100;
  if (name.includes("SOURCE_OF_TRUTH")) return 98;
  if (name.includes("DECISIONS")) return 90;
  if (
    name.includes("CONSTITUTION") ||
    name === "AGENTS.MD" ||
    name === "CLAUDE.MD" ||
    name === "GEMINI.MD"
  ) return 85;
  if (name.includes("ARCHITECTURE") || name === "PRODUCT.MD" || name === "DESIGN.MD") return 75;
  if (name === "README.MD") return 30;
  return 50;
}

type ContextDocument = { path: string; priority: number; content: string; truncated: boolean; needsDetail: boolean; bytes: number };

async function excerpt(file: string, chars: number): Promise<{ content: string; bytes: number; truncated: boolean }> {
  const handle = await open(file, "r");
  try {
    const bytes = (await handle.stat()).size;
    const buffer = Buffer.alloc(Math.min(bytes, chars * 4));
    const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
    const content = buffer.subarray(0, bytesRead).toString("utf8").slice(0, chars);
    return { content, bytes, truncated: bytesRead < bytes || Buffer.byteLength(content) < bytes };
  } finally { await handle.close(); }
}

export async function collectDocs(root: string, scope: string): Promise<ContextDocument[]> {
  const found: string[] = [];
  const ignored = /^(?:\.git|\.serena|node_modules|dist|build|\.next|\.cache|coverage|vendor|test|tests|validation|fixtures|templates?|.*archive.*|historical|history)$/i;
  let visited = 0;
  async function walk(dir: string, depth: number): Promise<void> {
    if (depth > 4 || visited >= 2000) return;
    let entries;
    try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
    // Inspect every file at a level before traversing children. Root CURRENT
    // cannot be crowded out by historical directories.
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      const scopedInstruction = /^(?:AGENTS|CLAUDE|GEMINI|README)\.md$/i.test(entry.name) && depth !== 0;
      if (!scopedInstruction && (DOC_NAMES.has(entry.name) || /(?:CURRENT|CHECKPOINT|HANDOFF|DECISION|CONSTITUTION|SOURCE_OF_TRUTH).*\.md$/i.test(entry.name))) {
        found.push(path.join(dir, entry.name));
      }
    }
    for (const entry of entries) {
      if (++visited >= 2000) break;
      if (entry.isDirectory() && !ignored.test(entry.name)) {
        const child = path.join(dir, entry.name);
        // A nested repository has its own context owner.
        try { await access(path.join(child, ".git")); continue; } catch { /* ordinary directory */ }
        await walk(child, depth + 1);
      }
    }
  }
  await walk(root, 0);
  // Scoped instructions belong only to the requested path's ancestors.
  let scoped = path.resolve(scope);
  try { scoped = await realpath(scoped); if (!(await stat(scoped)).isDirectory()) scoped = path.dirname(scoped); } catch { scoped = path.dirname(scoped); }
  while (scoped.startsWith(root + path.sep)) {
    for (const name of ["AGENTS.md", "CLAUDE.md", "GEMINI.md"]) {
      const file = path.join(scoped, name);
      try { await access(file); found.push(file); } catch { /* optional instruction */ }
    }
    scoped = path.dirname(scoped);
  }
  const ordered = [...new Set(found)].sort((a, b) => documentPriority(b) - documentPriority(a) || a.localeCompare(b));
  const result: ContextDocument[] = [];
  for (const file of ordered.slice(0, 24)) {
    try {
      const read = await excerpt(file, 1800);
      result.push({ path: path.relative(root, file), priority: documentPriority(file), ...read, needsDetail: read.truncated });
    } catch { /* unreadable candidates are not evidence */ }
  }
  return result;
}

// Cap the serialized text returned to the model, including JSON formatting and
// wrappers. This byte budget is observable; it is not an exact token count.
export function boundedBootstrap(result: Record<string, unknown>, maxBytes = 20 * 1024): Record<string, unknown> {
  result.needsDetail = false; // Include this final metadata field in every size check.
  result.budget = { maxToolResultBytes: maxBytes, unit: "UTF-8 bytes including text and structuredContent", exactTokenCount: false };
  const docs = result.documents as ContextDocument[];
  const size = () => Buffer.byteLength(JSON.stringify({ content: [{ type: "text", text: JSON.stringify(result, null, 2) }], structuredContent: result }));
  for (const doc of [...docs].reverse()) {
    if (size() <= maxBytes) break;
    if (doc.content) { doc.content = ""; doc.truncated = true; doc.needsDetail = true; }
  }
  // Durable semantic state is prioritized, but even this can outgrow a budget.
  // Return an explicit required-detail pointer instead of silently dropping it.
  if (size() > maxBytes) {
    const checkpoint = result.checkpoint as Record<string, unknown> | null;
    result.checkpoint = {
      objective: typeof checkpoint?.objective === "string" ? checkpoint.objective.slice(0, 600) : null,
      intent: typeof checkpoint?.intent === "string" ? checkpoint.intent.slice(0, 600) : null,
      summary: typeof checkpoint?.summary === "string" ? checkpoint.summary.slice(0, 400) : null,
      truncated: true, needsDetail: true, path: ".context/SNAPSHOT.json",
      reason: "Full semantic checkpoint exceeds navigation budget; read it before relying on complete constraints/decisions",
    };
  }
  if (size() > maxBytes) {
    result.documents = docs.slice(0, 12).map(doc => ({ ...doc, content: "", truncated: true, needsDetail: true }));
    result.serena = { available: true, mode: "local-files", needsDetail: true, path: ".serena/memories" };
    result.project = { root: (result.project as Record<string, unknown>).root, needsDetail: true };
    result.continuity = { freshness: (result.continuity as Record<string, unknown>).freshness, needsDetail: true, path: ".context/STATE.json" };
  }
  // On very large repositories the *metadata itself* may exceed the 8 KB
  // navigation budget even after checkpoint and document content are removed.
  // Trim repeatable metadata, never the durable on-disk journal, and leave
  // explicit pointers so the caller knows a separate read is required.
  if (size() > maxBytes) {
    result.documents = docs.slice(0, 4).map(doc => ({ path: doc.path, priority: doc.priority, needsDetail: true }));
    const project = result.project as Record<string, unknown>;
    result.project = { root: project.root, needsDetail: true };
    const continuity = result.continuity as Record<string, unknown>;
    result.continuity = { freshness: continuity?.freshness ?? "unknown", needsDetail: true, path: ".context/STATE.json" };
    const integrity = result.integrity as Record<string, unknown>;
    result.integrity = {
      coherent: integrity?.coherent ?? null,
      needsDetail: true,
      path: ".context/SNAPSHOT.json",
    };
    result.discovery = { needsDetail: true, scope: result.project, complete: false };
    result.ponytail = { needsDetail: true };
    result.notes = ["Read the referenced full checkpoint and relevant documents; metadata was bounded, not silently treated as verified."];
    result.deepRecall = { tool: "project_context_recall", needsDetail: true };
    result.policy = typeof result.policy === "string" ? result.policy.slice(0, 260) : "Consult local project policies before changes.";
  }
  // Last resort: preserve only stable identity, latest revision and a path to
  // full current constraints. No complete-context or compliance claim is made.
  if (size() > maxBytes) {
    result.documents = [];
    result.discovery = { needsDetail: true };
    result.notes = [];
    result.serena = { available: true, needsDetail: true, path: ".serena/memories" };
    const checkpoint = result.checkpoint as Record<string, unknown> | null;
    result.checkpoint = {
      objective: typeof checkpoint?.objective === "string" ? checkpoint.objective.slice(0, 240) : null,
      summary: typeof checkpoint?.summary === "string" ? checkpoint.summary.slice(0, 200) : null,
      truncated: true, needsDetail: true, path: ".context/SNAPSHOT.json",
    };
    result.policy = "Read .context/SNAPSHOT.json and relevant policies before material work.";
  }
  result.needsDetail = docs.some(doc => doc.needsDetail) || Boolean((result.checkpoint as Record<string, unknown> | null)?.needsDetail);
  // Never let an unusually large verification or continuity payload erase the
  // freshly-issued contextHandle. Omit repeatable metadata, not journal files.
  // Keep only a bounded pointer response; callers must read the original
  // checkpoint and relevant policies separately before acting.
  if (size() > maxBytes) {
    const identity = {
      mode: "fast",
      contextHandle: result.contextHandle,
      revision: result.revision,
      project: {
        root: typeof (result.project as Record<string, unknown> | null)?.root === "string"
          ? String((result.project as Record<string, unknown>).root).slice(0, 350)
          : null,
      },
      checkpoint: {
        path: ".context/SNAPSHOT.json",
        needsDetail: true,
        truncated: true,
      },
      integrity: { path: ".context/SNAPSHOT.json", needsDetail: true },
      documents: [],
      continuity: { path: ".context/STATE.json", needsDetail: true },
      serena: { path: ".serena/memories", needsDetail: true },
      policy: "Read .context/SNAPSHOT.json, project directives, and relevant current source before any material change.",
      needsDetail: true,
      budget: { maxToolResultBytes: maxBytes, unit: "UTF-8 bytes including text and structuredContent" },
    };
    for (const key of Object.keys(result)) delete result[key];
    Object.assign(result, identity);
  }
  if (size() > maxBytes) throw new Error("Context metadata exceeds output budget even after minimal safe pointer");
  return result;
}

function memoryScore(name: string, query: string): number {
  const tokens = query
    .toLowerCase()
    .split(/[^a-z0-9가-힣]+/)
    .filter((token) => token.length > 1);
  const normalized = name.toLowerCase();
  let score = /(current|decision|architecture|product|working_rules|overview|handoff)/.test(normalized)
    ? 2
    : 0;
  for (const token of tokens) if (normalized.includes(token)) score += 3;
  return score;
}

async function collectSerenaLocalMemories(
  root: string,
  query: string,
): Promise<{ available: boolean; mode: "local-files"; names: string[]; selected: Array<{ name: string; content: string; path: string; needsDetail: boolean }> }> {
  const memoriesRoot = path.join(root, ".serena", "memories");
  const candidates: Array<{ name: string; fullPath: string }> = [];

  async function walk(dir: string, depth: number): Promise<void> {
    if (depth > 6 || candidates.length >= 200) return;
    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        await walk(full, depth + 1);
      } else if (entry.name.endsWith(".md")) {
        candidates.push({
          name: path.relative(memoriesRoot, full).replace(/\.md$/i, ""),
          fullPath: full,
        });
      }
    }
  }

  await walk(memoriesRoot, 0);
  const ordered = candidates
    .map((item) => ({ ...item, score: memoryScore(item.name, query) }))
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));

  const selected: Array<{ name: string; content: string; path: string; needsDetail: boolean }> = [];
  for (const item of ordered.slice(0, 1)) {
    try {
      const read = await excerpt(item.fullPath, 600);
      selected.push({ name: item.name, content: read.content, path: path.relative(root, item.fullPath), needsDetail: read.truncated });
    } catch {
      // Ignore unreadable memory files.
    }
  }

  return {
    available: candidates.length > 0,
    mode: "local-files",
    names: ordered.slice(0, 30).map((item) => item.name),
    selected,
  };
}

async function ponytailLocalPolicy(): Promise<Record<string, unknown>> {
  const policyPath = path.join(os.homedir(), ".local/share/ponytail/AGENTS.md");
  try {
    await access(policyPath);
    return { available: true, mode: "local-file", path: policyPath, policy: "Reuse existing owners; prefer native/stdlib; add only necessary code.", needsDetail: true };
  } catch (error) {
    return {
      available: false,
      mode: "local-file",
      path: policyPath,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

function projectSnapshot(root: string): Record<string, unknown> {
  return {
    root,
    name: path.basename(root),
    branch: git(root, ["branch", "--show-current"]),
    head: git(root, ["rev-parse", "--short", "HEAD"]),
    status: git(root, ["status", "--short"], 256 * 1024),
    recentCommits: git(
      root,
      ["log", "-8", "--date=iso-strict", "--pretty=format:%h %ad %s"],
      128 * 1024,
    ),
  };
}

function claudeMemCounts(): Record<string, number> | null {
  const db = path.join(os.homedir(), ".claude-mem/claude-mem.db");
  const script = [
    "import sqlite3, json, sys",
    "c=sqlite3.connect(sys.argv[1])",
    "tabs=['observations','session_summaries','user_prompts','tool_uses']",
    "print(json.dumps({t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in tabs}))",
  ].join("; ");
  const result = spawnSync("python3", ["-c", script, db], {
    encoding: "utf8",
    timeout: 4_000,
  });
  if (result.status !== 0) return null;
  try {
    return JSON.parse(result.stdout.trim()) as Record<string, number>;
  } catch {
    return null;
  }
}

function hasAnyCount(counts: Record<string, number> | null): boolean {
  return Boolean(counts && Object.values(counts).some((value) => value > 0));
}

async function serenaDeepContext(root: string, query: string): Promise<Record<string, unknown>> {
  const serenaDir = path.join(root, ".serena");
  try {
    await access(serenaDir);
  } catch {
    return { available: false, skipped: true, reason: "project has no .serena directory" };
  }

  const spec: McpSpec = {
    command: "uvx",
    args: [
      "--from",
      "serena-agent",
      "serena",
      "start-mcp-server",
      "--project-from-cwd",
      "--context",
      "claude-code",
      "--open-web-dashboard",
      "False",
    ],
  };

  try {
    return await withMcpClient(spec, root, async (client) => {
      const listed = await withTimeout(client.callTool({ name: "list_memories", arguments: {} }), 12_000, "serena:list_memories");
      const text = toolText(listed);
      let names: string[] = [];
      try {
        const parsed = JSON.parse(text) as { memories?: unknown };
        names = Array.isArray(parsed.memories)
          ? parsed.memories.filter((value): value is string => typeof value === "string")
          : [];
      } catch {
        names = [];
      }

      const selectedNames = names
        .map((name) => ({ name, score: memoryScore(name, query) }))
        .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
        .slice(0, 4)
        .map((item) => item.name);

      const selected: Array<{ name: string; content?: string; error?: string }> = [];
      for (const name of selectedNames) {
        try {
          const memory = await withTimeout(
            client.callTool({ name: "read_memory", arguments: { memory_name: name } }),
            12_000,
            `serena:read_memory:${name}`,
          );
          selected.push({ name, content: toolText(memory).slice(0, 12 * 1024) });
        } catch (error) {
          selected.push({ name, error: error instanceof Error ? error.message : String(error) });
        }
      }
      return { available: true, mode: "single-mcp-session", names, selected };
    });
  } catch (error) {
    return { available: false, error: error instanceof Error ? error.message : String(error) };
  }
}

async function claudeMemDeepContext(root: string, query: string): Promise<Record<string, unknown>> {
  const counts = claudeMemCounts();
  if (!hasAnyCount(counts)) {
    return {
      available: true,
      skipped: true,
      historicalOnly: true,
      counts,
      reason: "claude-mem corpus is empty",
    };
  }

  const result = await callMcp(
    { command: "npx", args: ["-y", "claude-mem", "mcp"] },
    root,
    "search",
    { query: query || path.basename(root), limit: 12, orderBy: "date_desc" },
  );
  return result.ok
    ? {
        available: true,
        historicalOnly: true,
        counts,
        result: result.text?.slice(0, 20 * 1024),
      }
    : { available: false, historicalOnly: true, counts, error: result.error };
}

async function checkpoint(root: string, data: CheckpointData): Promise<Record<string, unknown>> {
  return commitCheckpoint(root, data, () => workingTreeFingerprint(root));
}

export function registerContextTools(server: McpServer, config: AppConfig, guard: ContextGuard): void {
  const authMetadata = toolAuthMetadata(config);

  server.registerTool(
    "project_context_bootstrap",
    {
      title: "Fast bootstrap project context",
      description:
        "MANDATORY at a local-project/session boundary and when resuming/continuing a project. Read-only fast path: reads current repository docs, checkpoint, Git state, local memories and cached policy. Recovers committed journal state in memory without lock/file writes; reports projection drift for explicit reconciliation. Use project_context_recall only if fast context is insufficient.",
      inputSchema: {
        path: z.string().optional().describe("Project path or any path inside it. Defaults to the server working directory."),
        query: z.string().default("").describe("Current task or continuation topic used to rank local Serena memories."),
        detail: z.enum(["navigation", "full"]).default("navigation").describe("Default compact navigation preserves semantic state and document pointers. Full returns bounded local excerpts; neither substitutes for relevant full instruction review."),
      },
      annotations: TOOL_ANNOTATIONS.readOnlyClosed,
      _meta: authMetadata,
    },
    async ({ path: inputPath, query, detail }) =>
      runTool(async () => {
        const started = performance.now();
        const root = await resolveProjectRoot(inputPath || config.defaultCwd);
        const inspected = await inspectCheckpoint(root);
        const checkpointState = inspected.snapshot;
        const [docs, serena, ponytail, continuity] = await Promise.all([
          collectDocs(root, inputPath || config.defaultCwd),
          collectSerenaLocalMemories(root, query || path.basename(root)),
          ponytailLocalPolicy(),
          continuityStatus(root),
        ]);

        const snapshot = projectSnapshot(root);
        const contextHandle = guard.issue(root, snapshot);
        const result: Record<string, unknown> = {
          mode: "fast",
          contextHandle,
          revision: checkpointState?.revision ?? 0,
          checkpoint: checkpointState?.data ?? null,
          integrity: inspected.integrity,
          verificationEvidence: checkpointState?.verificationEvidence ?? null,
          verificationFreshness: checkpointState?.verificationEvidence?.fingerprint && continuity.currentFingerprint
            ? checkpointState.verificationEvidence.fingerprint === continuity.currentFingerprint ? "unchanged" : "changed"
            : "unknown",
          elapsedMs: Math.round((performance.now() - started) * 10) / 10,
          policy: POLICY,
          project: snapshot,
          documents: docs,
          discovery: { maxDepth: 4, maxEntries: 2000, maxDocuments: 24, scope: inputPath || config.defaultCwd, complete: false },
          serena,
          ponytail,
          continuity,
          deepRecall: {
            tool: "project_context_recall",
            useWhen: "Fast context is insufficient, historical rationale is missing, or semantic Serena retrieval is needed.",
          },
          notes: [
            "Fast bootstrap performs local file/Git reads only; it does not start Serena, claude-mem, or Headroom subprocesses.",
            "Memory results are historical/reference material only.",
            "If any retrieved memory conflicts with code, Git, CURRENT/CHECKPOINT/HANDOFF, or accepted decisions, use the higher-authority current evidence and report the conflict.",
            "Navigation excerpts are not proof of full instruction review. Read needsDetail documents before relevant material work.",
          ],
        };
        if (detail === "navigation") {
          result.policy = "Current executable evidence establishes observed state; current user requirements/prohibitions remain binding. Read relevant project instructions/CURRENT contracts before material work. Memories are reference only. Checkpoint meaningful state transitions through the shared store with baseRevision; explicitly reconcile drift. Deep recall is on demand.";
          result.project = { root, name: snapshot.name, branch: snapshot.branch, head: snapshot.head, status: typeof snapshot.status === "string" ? snapshot.status.slice(0, 600) : snapshot.status };
          result.documents = docs.slice(0, 12).map(doc => ({ ...doc, content: "", truncated: true, needsDetail: true }));
          result.serena = { mode: "local-files", available: serena.available, historicalOnly: true, path: ".serena/memories", useWhen: "Relevant current state is insufficient" };
          result.ponytail = { role: "implementation discipline only", available: ponytail.available };
          result.notes = ["Document pointers require relevant full reads; omitted excerpts are not proof of review. Journal recovery is in memory; checkpoint repairs known stale projections. Local instructions do not make web chat-only events visible to MCP."];
        }
        return boundedBootstrap(result, detail === "navigation" ? 8 * 1024 : 20 * 1024);
      }),
  );

  server.registerTool(
    "project_context_recall",
    {
      title: "Deep recall project context",
      description:
        "On-demand slow path. Use only when fast bootstrap is insufficient. Reuses one Serena MCP process/session for semantic project-memory retrieval and queries claude-mem only when its local corpus contains records. Historical results never override current code/Git/current-state documents.",
      inputSchema: {
        path: z.string().optional().describe("Project path or any path inside it. Defaults to the server working directory."),
        query: z.string().min(1).describe("Specific missing historical or semantic context to retrieve."),
      },
      annotations: TOOL_ANNOTATIONS.readOnlyClosed,
      _meta: authMetadata,
    },
    async ({ path: inputPath, query }) =>
      runTool(async () => {
        const started = performance.now();
        const root = await resolveProjectRoot(inputPath || config.defaultCwd);
        const [serena, claudeMem] = await Promise.all([
          serenaDeepContext(root, query),
          claudeMemDeepContext(root, query),
        ]);
        return {
          mode: "deep",
          elapsedMs: Math.round((performance.now() - started) * 10) / 10,
          project: { root, name: path.basename(root) },
          serena,
          claudeMem,
          authorityReminder:
            "Deep recall is historical/reference context only. Current code/runtime/Git and current-state/source-of-truth/checkpoint/handoff documents remain authoritative.",
        };
      }),
  );

  server.registerTool(
    "project_context_checkpoint",
    {
      title: "Checkpoint project and conversation context",
      description:
        "MANDATORY after material changes and after meaningful project-conversation events such as approval/rejection, architecture decisions, reversals, new constraints, milestone completion, discovered blockers, or project handoff. Writes rolling SESSION_CHECKPOINT/HANDOFF plus append-only WORKLOG/CONVERSATION and durable DECISIONS. Do not call for trivial chat.",
      inputSchema: CHECKPOINT_INPUT,
      annotations: TOOL_ANNOTATIONS.additiveNonIdempotentClosed,
      _meta: authMetadata,
    },
    async ({
      path: inputPath,
      eventId, baseRevision, clearFields, replaceFields, reconcileProjection, captureToken,
      eventType,
      summary,
      objective,
      intent,
      decisions,
      rejected,
      constraints,
      openIssues,
      next,
      files,
      verification,
    }) =>
      runTool(async () => {
        const started = performance.now();
        const root = await resolveProjectRoot(inputPath || config.defaultCwd);
        const result = await checkpoint(root, {
          eventId, baseRevision, clearFields, replaceFields, reconcileProjection, captureToken,
          eventType,
          summary,
          objective,
          intent,
          decisions,
          rejected,
          constraints,
          openIssues,
          next,
          files,
          verification,
        });
        return {
          ...result,
          elapsedMs: Math.round((performance.now() - started) * 10) / 10,
        };
      }),
  );

  server.registerTool(
    "project_context_health",
    {
      title: "Check context subsystem",
      description:
        "Check installed context helpers and persistence health. Reports whether claude-mem is actually retaining records and explains fast/deep path behavior.",
      inputSchema: {},
      annotations: TOOL_ANNOTATIONS.readOnlyClosed,
      _meta: authMetadata,
    },
    async () =>
      runTool(async () => {
        const home = os.homedir();
        const commandExists = (command: string) =>
          spawnSync("/bin/zsh", ["-lc", `command -v ${command}`], {
            encoding: "utf8",
            timeout: 3_000,
          }).status === 0;

        const db = path.join(home, ".claude-mem/claude-mem.db");
        const counts = claudeMemCounts();
        const ponytailPath = path.join(home, ".local/share/ponytail/AGENTS.md");
        const ponytailInstalled = await access(ponytailPath).then(() => true).catch(() => false);

        return {
          fastPath: {
            externalSubprocesses: false,
            sources: ["Git", "CURRENT/CHECKPOINT/HANDOFF/docs", "local .serena/memories files", "local Ponytail AGENTS.md"],
          },
          deepPath: {
            tool: "project_context_recall",
            serena: "single MCP child process/session per recall",
            claudeMem: "skipped automatically when corpus is empty",
            headroom: "compression only; invoke only when context volume requires it",
          },
          serena: { installed: commandExists("serena") || commandExists("uvx") },
          claudeMem: {
            installed: commandExists("claude-mem") || commandExists("npx"),
            db,
            counts,
            captureHealthy: hasAnyCount(counts),
          },
          ponytail: { installed: ponytailInstalled, path: ponytailPath },
          headroom: {
            installed: commandExists("headroom"),
            role: "compression only; never authoritative memory",
          },
          policy: POLICY,
        };
      }),
  );
}

export const PROJECT_CONTEXT_POLICY = POLICY;
