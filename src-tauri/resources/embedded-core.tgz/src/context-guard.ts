import { spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import path from "node:path";

import { resolveProjectRoot } from "./context-tools.js";

function git(root: string, args: string[]): string | null {
  const result = spawnSync("git", args, { cwd: root, encoding: "utf8", timeout: 3000, maxBuffer: 16 * 1024 });
  return result.status === 0 ? result.stdout.trim() : null;
}

type Handle = { root: string; head: unknown; branch: unknown; git: boolean; expires: number };

// Explicit handles work on stateless HTTP: they are held by shared services,
// never by a request's short-lived McpServer or an inferred transport session.
export class ContextGuard {
  private readonly handles = new Map<string, Handle>();
  private readonly processRoots = new Map<string, string>();
  issue(root: string, snapshot: Record<string, unknown>): string {
    for (const [key, value] of this.handles) if (value.expires <= Date.now()) this.handles.delete(key);
    if (this.handles.size >= 1024) this.handles.delete(this.handles.keys().next().value!);
    const token = randomUUID();
    this.handles.set(token, { root, head: snapshot.head, branch: snapshot.branch,
      git: git(root, ["rev-parse", "--show-toplevel"]) !== null, expires: Date.now() + 30 * 60 * 1000 });
    return token;
  }
  async require(inputs: string[], token: string | undefined): Promise<void> {
    const handle = token ? this.handles.get(token) : undefined;
    for (const input of inputs) {
      const root = await resolveProjectRoot(input);
      const recovery = `CONTEXT_REQUIRED: call project_context_bootstrap with path=${JSON.stringify(root)}, read the returned context, then retry with its contextHandle. No action was executed.`;
      if (!handle || handle.expires <= Date.now()) throw new Error(recovery);
      const scopeMatch = root === handle.root || (!handle.git && root.startsWith(handle.root + path.sep) && !git(root, ["rev-parse", "--show-toplevel"]));
      if (!scopeMatch) throw new Error(recovery);
      if (git(handle.root, ["rev-parse", "--short", "HEAD"]) !== handle.head || git(handle.root, ["branch", "--show-current"]) !== handle.branch) {
        this.handles.delete(token!); throw new Error(recovery);
      }
    }
    handle!.expires = Date.now() + 30 * 60 * 1000;
  }
  bindProcess(id: string, root: string): void { this.processRoots.set(id, root); }
  async requireProcess(id: string, token: string | undefined): Promise<void> {
    const root = this.processRoots.get(id);
    if (!root) throw new Error("Unknown process session");
    await this.require([root], token);
  }
}
