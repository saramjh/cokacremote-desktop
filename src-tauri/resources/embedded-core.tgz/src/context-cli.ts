import { mkdir, rename, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import * as z from 'zod/v4';
import { CHECKPOINT_INPUT, resolveProjectRoot, workingTreeFingerprint } from './context-tools.js';
import { commitCheckpoint } from './context-store.js';
import { ackPath, handleContextHook, localCapsule, type ContextClient } from './context-local.js';

const quote = (s: string) => `'${s.replaceAll("'", "'\\''")}'`;
export const contextCommand = `${quote(process.execPath)} ${quote(fileURLToPath(import.meta.url))}`;
const args = process.argv.slice(2);
const option = (name: string) => { const index = args.indexOf(name); return index < 0 ? undefined : args[index + 1]; };
async function stdin() {
  let text = ''; for await (const chunk of process.stdin) { text += String(chunk); if (Buffer.byteLength(text) > 256 * 1024) throw new Error('JSON stdin exceeds 256KiB'); }
  return JSON.parse(text || '{}');
}
try {
  const command = args[0];
  let result: unknown;
  if (command === 'hook') {
    const client = z.enum(['codex', 'claude', 'cursor', 'gemini']).parse(option('--client')) as ContextClient;
    result = await handleContextHook(client, await stdin(), contextCommand);
  } else if (command === 'bootstrap') {
    result = (await localCapsule(option('--path') || process.cwd())).capsule;
  } else if (command === 'checkpoint') {
    const value = z.object(CHECKPOINT_INPUT).parse(await stdin());
    const root = await resolveProjectRoot(option('--path') || value.path || process.cwd());
    if (value.baseRevision === undefined) throw new Error('Local checkpoint requires baseRevision from the current capsule');
    const { path: _path, ...data } = value;
    result = await commitCheckpoint(root, data, () => workingTreeFingerprint(root));
  } else if (command === 'ack') {
    const root = await resolveProjectRoot(option('--path') || process.cwd());
    const token = z.string().min(1).max(200).parse(option('--capture-token'));
    const value = z.object({ reason: z.string().trim().min(3).max(1000) }).parse(await stdin());
    const current = await workingTreeFingerprint(root);
    const file = ackPath(root, token);
    await mkdir(path.dirname(file), { recursive: true });
    const temp = file + '.tmp';
    await writeFile(temp, JSON.stringify({ token, reason: value.reason, fingerprint: current.fingerprint ?? null }) + '\n', { mode: 0o600 });
    await rename(temp, file);
    result = { root, acknowledged: true, token };
  } else throw new Error('Use bootstrap, checkpoint, ack, or hook --client CLIENT');
  process.stdout.write(JSON.stringify(result) + '\n');
} catch (error) {
  process.stderr.write(`agent-context: ${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}
