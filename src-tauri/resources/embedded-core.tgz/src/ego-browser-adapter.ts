import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

export type BrowserIntent = "SCRAPE" | "DOM_ACT" | "VISUAL_SOLVE";
export type EgoAction =
  | { kind: "observe" }
  | { kind: "click" | "fill" | "type" | "press"; selector: string; value?: string };

export class EgoBrowserError extends Error {
  constructor(message: string, readonly actionMayHaveRun: boolean) {
    super(message);
    this.name = "EgoBrowserError";
  }
}

/** Opaque natural-language actions still require the existing adaptive harness. */
export function parseEgoAction(intent: BrowserIntent, description: string): EgoAction | null {
  if (intent === "VISUAL_SOLVE") return null;
  const raw = description.trim();
  if (!raw) return { kind: "observe" };
  const match = /^(click|fill|type|press):\s*(.+)$/is.exec(raw);
  if (!match) return null;
  const kind = match[1]!.toLowerCase() as Exclude<EgoAction["kind"], "observe">;
  const content = match[2]!.trim();
  if (kind === "click") return content ? { kind, selector: content } : null;
  const pivot = content.indexOf(" || ");
  if (pivot < 1 || pivot + 4 >= content.length) return null;
  return { kind, selector: content.slice(0, pivot).trim(), value: content.slice(pivot + 4) };
}

export function resolveEgoBrowserBin(): string {
  const configured = process.env.MCP_EGO_BROWSER_BIN?.trim();
  if (configured) return configured;
  const path = join(homedir(), ".local", "bin", "ego-browser");
  return existsSync(path) ? path : "ego-browser";
}

export interface EgoBrowserInput {
  url: string;
  intent: BrowserIntent;
  action: EgoAction;
  workspace: string;
  timeoutMs: number;
}

const RESULT_PREFIX = "__COKAC_EGO_RESULT__";
const ERROR_PREFIX = "__COKAC_EGO_ERROR__";

/** User content is serialized as a JS literal; it is never interpolated into JS source. */
export function buildEgoScript(input: EgoBrowserInput): string {
  const job = JSON.stringify({
    ...input,
    taskName: `cokacremote-${input.workspace}-${randomUUID()}`,
  });
  return `
const job = ${job};
let task;
let actionStarted = false;
let result;
let failure;
try {
  task = await taskSpace(job.taskName);
  const page = task.page("p1");
  await page.goto(job.url, {timeout: Math.max(5000, job.timeoutMs - 1500), waitUntil: "domcontentloaded"});
  if (job.action.kind !== "observe") {
    actionStarted = true;
    if (job.action.kind === "click") {
      await page.click(job.action.selector, {label: "Execute requested browser click"});
    } else if (job.action.kind === "fill") {
      await page.fill(job.action.selector, job.action.value);
    } else if (job.action.kind === "type") {
      await page.fill(job.action.selector, job.action.value);
    } else if (job.action.kind === "press") {
      await page.press(job.action.selector, job.action.value);
    }
  }
  const info = await page.evaluate(() => ({
    url: location.href,
    title: document.title,
    text: (document.body?.innerText || "").slice(0, 6000),
  }));
  const snapshot = (await page.snapshot()).slice(0, 9000);
  result = { ...info, snapshot, taskSpaceId: task.spaceId, action: job.action.kind };
} catch (e) {
  failure = String(e);
} finally {
  if (task) {
    try { await task.finish({keep: []}); }
    catch (e) { failure ??= "Failed to close ego task space: " + String(e); }
  }
}
if (failure) {
  console.error(${JSON.stringify(ERROR_PREFIX)} + JSON.stringify({message: failure.slice(0, 2000), actionStarted}));
  process.exitCode = 1;
} else {
  console.error(${JSON.stringify(RESULT_PREFIX)} + JSON.stringify(result));
}
`;
}

export async function runEgoBrowserTask(
  input: EgoBrowserInput,
  options: { bin?: string } = {},
): Promise<Record<string, unknown>> {
  // Limit protocol to real web navigation, not file/javascript/chrome URLs.
  const url = new URL(input.url);
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new EgoBrowserError("Only HTTP(S) URLs are supported by ego browser automation", false);
  }
  const bin = options.bin || resolveEgoBrowserBin();
  const script = buildEgoScript(input);
  return await new Promise((resolve, reject) => {
    const child = spawn(bin, ["nodejs"], { stdio: ["pipe", "pipe", "pipe"] });
    let output = "";
    let settled = false;
    const fail = (message: string, actionMayHaveRun: boolean) => {
      if (settled) return;
      settled = true;
      reject(new EgoBrowserError(message, actionMayHaveRun));
    };
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      fail(`ego-browser timed out after ${input.timeoutMs}ms`, input.action.kind !== "observe");
    }, input.timeoutMs);
    const collect = (chunk: Buffer) => {
      if (output.length < 1_000_000) output += chunk.toString("utf8");
      else child.kill("SIGKILL");
    };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    child.on("error", (error) => {
      clearTimeout(timer);
      fail(`ego-browser unavailable: ${error.message}`, false);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      if (settled) return;
      const records = output.split(/\r?\n/);
      // ego-browser v0.6 prefixes console.error() with "[error] ".
      const resultLine = records.findLast((line) => line.includes(RESULT_PREFIX));
      const errorLine = records.findLast((line) => line.includes(ERROR_PREFIX));
      if (code === 0 && resultLine) {
        try {
          const details = JSON.parse(resultLine.slice(resultLine.indexOf(RESULT_PREFIX) + RESULT_PREFIX.length)) as Record<string, unknown>;
          settled = true;
          resolve({success: true, backend: "ego-lite", url: input.url, intent: input.intent,
            result: JSON.stringify(details), details});
        } catch {
          fail("ego-browser returned malformed JSON", input.action.kind !== "observe");
        }
        return;
      }
      if (errorLine) {
        try {
          const info = JSON.parse(errorLine.slice(errorLine.indexOf(ERROR_PREFIX) + ERROR_PREFIX.length)) as {message: string; actionStarted: boolean};
          fail(`ego-browser task failed: ${info.message}`, info.actionStarted);
          return;
        } catch { /* Use generic failure below. */ }
      }
      fail(`ego-browser process failed (exit ${code}): ${output.slice(-700)}`, input.action.kind !== "observe");
    });
    // Critical: ego-browser waits for EOF when MCP passes a persistent stdin pipe.
    child.stdin.on("error", () => undefined);
    child.stdin.end(script);
  });
}
