import { describe, expect, it } from 'vitest';
import { boundedBootstrap } from '../src/context-tools.js';

const encodedBytes = (value: unknown) => Buffer.byteLength(JSON.stringify({
  content: [{type: 'text', text: JSON.stringify(value, null, 2)}],
  structuredContent: value
}));

function huge(): Record<string, unknown> {
  return {
    mode: 'fast',
    contextHandle: 'test-context-handle',
    revision: 152,
    checkpoint: { summary: 'Latest verified 61/100 K100 and 39 remain. '.repeat(80), objective:'Educator resource editorial receipts',
      intent:'Prevent repeated publisher attempts', decisions:Array(100).fill('Historic decision of independent author and editor'), constraints:Array(130).fill('No duplicate publisher and no fabricated receipt'), openIssues:Array(110).fill('Investigate rights and publishing') },
    integrity: {coherent:true,driftPaths:[],repairPaths:[],warning:null},
    verificationEvidence: {revision:152,recordedAt:'2026-10-21T09:00:00Z'},
    policy:'Full project policy '.repeat(30),
    project: {root:'/Users/test/DEV/space_atlas_student',name:'space_atlas_student',head:'abc',status:'U'.repeat(600)},
    documents:Array.from({length:24},(_,i)=>({path:'docs/deep/nested/document-'.concat(String(i),'.md'),priority:90-i,content:'Reference content '.repeat(130),bytes:2400,truncated:true,needsDetail:true})),
    discovery:{maxDepth:4,maxEntries:2000,maxDocuments:24,scope:'/Users/test/DEV/space_atlas_student',complete:false},
    serena:{available:true,mode:'local-files',names:Array.from({length:30},(_,i)=>'old-project-memory-'+i),selected:[{name:'current_state',content:'long project memory'.repeat(100)}]},
    ponytail:{available:true,role:'implementation discipline only',extra:'old guidance'.repeat(70)},
    continuity:{supported:true,freshness:'unchanged',checkpointChangedPaths:Array.from({length:120},(_,i)=>'?? strategy/batches/very-long-editor-resource-'+i+'.csv'),currentChangedPaths:Array.from({length:120},(_,i)=>'?? strategy/batches/very-long-editor-resource-'+i+'.csv')},
    deepRecall:{tool:'project_context_recall',useWhen:'When needed'},
    notes:['historical context needs review '.repeat(100)]
  };
}

describe('bounded project bootstrap metadata', () => {
  it('fits a pathological but valid large project into the 8 KiB navigation envelope', () => {
    const r = boundedBootstrap(huge(),8*1024);
    expect(encodedBytes(r)).toBeLessThanOrEqual(8192);
    expect(r.revision).toBe(152);
    expect(r.contextHandle).toBe('test-context-handle');
    expect(r.needsDetail).toBe(true);
    expect(JSON.stringify(r)).toContain('.context/SNAPSHOT.json');
    expect(JSON.stringify(r)).not.toContain('Historic decision of independent author');
  });
  it('remains inside the 20 KiB full-detail envelope and retains explicit on-disk pointers', () => {
    const r=boundedBootstrap(huge(),20*1024);
    expect(encodedBytes(r)).toBeLessThanOrEqual(20*1024);
    expect(r.contextHandle).toBe('test-context-handle');
    expect(JSON.stringify(r)).toContain('.context/SNAPSHOT.json');
    expect(r.needsDetail).toBe(true);
  });
  it('fails open to a bounded pointer despite pathological verification metadata without losing revision or handle', () => {
    const input=huge();
    input.verificationEvidence={ fingerprint:'x'.repeat(700_000), prior: Array(100).fill('Old provenance details'.repeat(70)) };
    input.integrity={ coherent:false, driftPaths:Array(1000).fill('a/very/long/project/file/path'), notes:'x'.repeat(100_000) };
    const r=boundedBootstrap(input,8*1024);
    expect(encodedBytes(r)).toBeLessThanOrEqual(8192);
    expect(r.contextHandle).toBe('test-context-handle');
    expect(r.revision).toBe(152);
    expect(r.needsDetail).toBe(true);
    expect((r.checkpoint as any).path).toBe('.context/SNAPSHOT.json');
    expect(JSON.stringify(r)).not.toContain('Old provenance details');
    expect(JSON.stringify(r)).not.toContain('Historic decision');
  });
  it('preserves small project context without pretending detail is missing', () => {
    const input=huge();input.documents=[];input.checkpoint={summary:'A small valid checkpoint',objective:'Continue current work'};input.policy='Short policy';input.continuity={freshness:'unchanged'};input.serena={available:false};input.ponytail={available:false};input.notes=[];input.project={root:'/tmp/project'};input.discovery={complete:false};
    const r=boundedBootstrap(input,8192);
    expect(encodedBytes(r)).toBeLessThanOrEqual(8192);
    expect((r.checkpoint as any).summary).toBe('A small valid checkpoint');
  });
});
