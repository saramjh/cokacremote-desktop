import { mkdtemp, readFile, rm, writeFile, chmod } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { EgoBrowserError, parseEgoAction, runEgoBrowserTask, buildEgoScript } from "../src/ego-browser-adapter.js";

const job = (action = { kind: "observe" } as const) => ({
  url: "https://example.com/", intent: "SCRAPE" as const, action,
  workspace: "regression", timeoutMs: 5000,
});

describe("ego-lite adapter", () => {
  let root = "";
  let bin = "";
  beforeAll(async () => {
    root = await mkdtemp(join(tmpdir(), "cokac-ego-adapter-"));
    bin = join(root, "ego-browser");
    await writeFile(bin, `#!/usr/bin/env node
let input = '';
process.stdin.on('data', s => input += s);
process.stdin.on('end', () => {
  if (!input.includes('taskSpace')) process.exit(3);
  console.error('__COKAC_EGO_RESULT__' + JSON.stringify({url:'https://example.com/',title:'Example Domain',action:'observe',text:'test'}));
});
`);
    await chmod(bin, 0o755);
  });
  afterAll(async () => { if (root) await rm(root, { recursive: true, force: true }); });

  it("parses supported explicit actions and declines unsupported natural language", () => {
    expect(parseEgoAction("SCRAPE", "")).toEqual({kind:"observe"});
    expect(parseEgoAction("DOM_ACT", "click: button#submit")).toEqual({kind:"click",selector:"button#submit"});
    expect(parseEgoAction("DOM_ACT", "fill: #search || birds")).toEqual({kind:"fill",selector:"#search",value:"birds"});
    expect(parseEgoAction("DOM_ACT", "press: input#query || Enter")).toEqual({kind:"press",selector:"input#query",value:"Enter"});
    expect(parseEgoAction("VISUAL_SOLVE", "click: button")).toBeNull();
    expect(parseEgoAction("DOM_ACT", "click the submit button")).toBeNull();
    expect(parseEgoAction("DOM_ACT", "type: #search")).toBeNull();
  });

  it("quotes suspicious user text and keeps a unique space label", () => {
    const action = {kind: "fill" as const, selector: "#input", value: "');console.log('injected');"};
    const script = buildEgoScript({...job(), action});
    expect(script).toContain(JSON.stringify(action.value));
    expect(script).toContain("task.finish({keep: []})");
    expect(script).toContain('cokacremote-regression-');
  });

  it("passes a complete Node script on stdin and waits for EOF", async () => {
    const result = await runEgoBrowserTask(job(), {bin});
    expect(result).toMatchObject({ success: true, backend: "ego-lite" });
    expect(JSON.parse(result.result as string)).toMatchObject({title: "Example Domain"});
  });

  it("indicates missing executable is retry-safe", async () => {
    await expect(runEgoBrowserTask(job(), {bin:join(root,"missing-binary")}))
      .rejects.toMatchObject({name:"EgoBrowserError",actionMayHaveRun:false});
  });

  it("rejects non-web URL schemes", async () => {
    await expect(runEgoBrowserTask({...job(),url:"file:///etc/passwd"},{bin}))
      .rejects.toMatchObject({actionMayHaveRun:false});
  });

  it("rejects malformed backend output after an uncertain side-effecting click", async () => {
    const bad=join(root,"invalid-ego");
    await writeFile(bad,"#!/bin/sh\ncat >/dev/null\nprintf 'oops' >&2\nexit 2\n");
    await chmod(bad,0o755);
    try {
      await runEgoBrowserTask({...job(),intent:"DOM_ACT",action:{kind:"click",selector:"#submit"}},{bin:bad});
      throw new Error("Unexpected success");
    } catch(error){
      expect(error).toBeInstanceOf(EgoBrowserError);
      expect((error as EgoBrowserError).actionMayHaveRun).toBe(true);
    }
  });
});
