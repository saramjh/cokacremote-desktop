import { mkdtemp, rm, writeFile, chmod } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { AddressInfo } from "node:net";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { beforeAll, afterAll, describe, expect, it } from "vitest";
import { loadConfig } from "../src/config.js";
import { startHttpServer, type RunningHttpServer } from "../src/http-server.js";
import { createServices } from "../src/mcp-server.js";

describe("browse_and_execute backend routing", () => {
  let root = "";
  let server: RunningHttpServer;
  let client: Client;
  let transport: StreamableHTTPClientTransport;
  const original = { ego:process.env.MCP_EGO_BROWSER_BIN, harness:process.env.BROWSER_HARNESS_BIN,
    engine:process.env.MCP_BROWSER_ENGINE };
  beforeAll(async () => {
    root = await mkdtemp(path.join(os.tmpdir(),"cokac-browser-route-"));
    const ego = path.join(root,"ego");
    const harness = path.join(root,"harness");
    await writeFile(ego,`#!/usr/bin/env node
let s='';process.stdin.on('data',v=>s+=v);process.stdin.on('end',()=>{
 if(process.env.EGO_SIMULATE_FAILURE === '1') {
  console.error('__COKAC_EGO_ERROR__'+JSON.stringify({message:'failure',actionStarted:true}));process.exitCode=1;
 } else {console.error('__COKAC_EGO_RESULT__'+JSON.stringify({title:'Synthetic ego result',url:'https://example.com/'}));}
});
`);
    await writeFile(harness, "#!/bin/sh\nprintf 'MOCK_LEGACY_SUCCESS\\n'\n");
    await chmod(ego,0o755);await chmod(harness,0o755);
    process.env.MCP_EGO_BROWSER_BIN=ego;
    process.env.BROWSER_HARNESS_BIN=harness;
    delete process.env.MCP_BROWSER_ENGINE;
    const config=loadConfig({MCP_AUTH_TOKEN:"test-browser",MCP_HOST:"127.0.0.1",MCP_ENABLE_BROWSER_TOOLS:"true",MCP_DEFAULT_CWD:root},root);
    config.port=0;
    server=await startHttpServer(config,createServices(config));
    const endpoint=new URL(`http://127.0.0.1:${(server.httpServer.address() as AddressInfo).port}${config.endpoint}`);
    client=new Client({name:"routing",version:"1"});
    transport=new StreamableHTTPClientTransport(endpoint,{requestInit:{headers:{Authorization:"Bearer test-browser"}}});
    await client.connect(transport);
  });
  afterAll(async()=>{
    await client?.close(); await server?.close();
    await rm(root,{recursive:true,force:true});
    for(const [name,key] of Object.entries({MCP_EGO_BROWSER_BIN:original.ego,BROWSER_HARNESS_BIN:original.harness,MCP_BROWSER_ENGINE:original.engine})){
      if(key===undefined)delete process.env[name];else process.env[name]=key;
    }
    delete process.env.EGO_SIMULATE_FAILURE;
  });

  const call=async(args:Record<string,unknown>)=>{
    const result=await client.callTool({name:"browse_and_execute",arguments:{url:"https://example.com/",intent:"SCRAPE",timeoutMs:7000,...args}});
    return {isError:result.isError??false,body:result.structuredContent as Record<string,unknown>};
  };

  it("routes ordinary scraping to ego by default", async()=>{
    const r=await call({});
    expect(r.isError).toBe(false);
    expect(r.body).toMatchObject({backend:"ego-lite",success:true});
  });

  it("routes natural language action to adaptive legacy harness", async()=>{
    const r=await call({intent:"DOM_ACT",action_description:"click the login button"});
    expect(r.body).toMatchObject({
      backend:"legacy-harness",result:"MOCK_LEGACY_SUCCESS",
      success:false,browserExecuted:true,actionOutcome:"unverified_external_effect",
      providerReceiptVerified:false,retrySafe:false,
    });
  });

  it("never confuses successful legacy browser completion with verified publisher form submission",async()=>{
    const r=await call({intent:"DOM_ACT",action_description:"fill form and click submit"});
    expect(r.isError).toBe(false);
    expect(r.body.success).toBe(false);
    expect(r.body.providerReceiptVerified).toBe(false);
    expect(r.body.retrySafe).toBe(false);
  });

  it("honors explicit legacy override", async()=>{
    const r=await call({engine:"legacy"});
    expect(r.body.backend).toBe("legacy-harness");
  });

  it("does not retry side-effecting actions after uncertain completion", async()=>{
    process.env.EGO_SIMULATE_FAILURE="1";
    try {
      const r=await call({intent:"DOM_ACT",action_description:"click: #purchase"});
      expect(r.isError).toBe(true);
      expect(r.body.error).toContain("ego-browser task failed");
    } finally {delete process.env.EGO_SIMULATE_FAILURE;}
  });

  it("allows read-only fallback when ego execution fails", async()=>{
    process.env.EGO_SIMULATE_FAILURE="1";
    try {
      const r=await call({});
      expect(r.isError).toBe(false);
      expect(r.body).toMatchObject({backend:"legacy-harness",result:"MOCK_LEGACY_SUCCESS"});
      expect(r.body.fallbackReason).toContain("ego-browser task failed");
    }finally{delete process.env.EGO_SIMULATE_FAILURE;}
  });
});
