import { afterEach, describe, expect, it } from 'vitest';
import { mkdtemp, mkdir, readFile, readdir, rm } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import os from 'node:os';
import { handleContextHook } from '../src/context-local.js';
import { commitCheckpoint, type CheckpointData } from '../src/context-store.js';
import { workingTreeFingerprint } from '../src/context-tools.js';
import { mergeContextHooks } from '../src/context-hook-config.js';
const roots: string[] = [];
async function setup() { const base = await mkdtemp(path.join(os.tmpdir(), 'global-hook-')); roots.push(base); const root = path.join(base, 'new-project'); await mkdir(root); execFileSync('git', ['init', '-q', root]); return { root, runtime: path.join(base, 'runtime') }; }
const data = (extra: Partial<CheckpointData>): CheckpointData => ({ summary: 'meaningful decision', eventType: 'decision', decisions: [], rejected: [], constraints: [], openIssues: [], next: [], files: [], verification: [], ...extra });
afterEach(async () => { for (const root of roots.splice(0)) await rm(root, { recursive: true, force: true }); });
describe('global lifecycle adapter', () => {
 it('captures an event in the common store and confirms it at Stop', async () => {
  const { root, runtime } = await setup(); const common = { cwd: root, session_id: 'new-session' };
  const output = await handleContextHook('codex', { ...common, hook_event_name: 'UserPromptSubmit', turn_id: 'first', prompt: 'A rejected, B accepted' }, 'node context-cli', runtime);
  const text = String((output.hookSpecificOutput as Record<string, unknown>).additionalContext);
  const token = /Context event token: ([^;]+)/.exec(text)![1]!;
  await commitCheckpoint(root, data({ captureToken: token, baseRevision: 0, decisions: ['B'], rejected: ['A'] }), () => workingTreeFingerprint(root));
  expect(await handleContextHook('codex', { ...common, hook_event_name: 'Stop' }, 'node context-cli', runtime)).toEqual({});
 });
 it('bounds missing capture continuation and preserves the original token', async () => {
  const { root, runtime } = await setup(); const common = { cwd: root, session_id: 'session' };
  await handleContextHook('codex', { ...common, hook_event_name: 'UserPromptSubmit', turn_id: 'original', prompt: 'durable change' }, 'node context-cli', runtime);
  const first = await handleContextHook('codex', { ...common, hook_event_name: 'Stop' }, 'node context-cli', runtime);
  expect(first.decision).toBe('block');
  await handleContextHook('codex', { ...common, hook_event_name: 'UserPromptSubmit', turn_id: 'extra', prompt: first.reason }, 'node context-cli', runtime);
  const second = await handleContextHook('codex', { ...common, hook_event_name: 'Stop', stop_hook_active: true }, 'node context-cli', runtime);
  expect(second.decision).toBeUndefined(); expect(second.systemMessage).toMatch(/unconfirmed/);
 });
 it('retains interrupted input as uncommitted instead of replacing or approving it', async () => {
  const { root, runtime } = await setup(); const common = { cwd: root, session_id: 'session' };
  await handleContextHook('codex', { ...common, hook_event_name: 'UserPromptSubmit', turn_id: 'one', prompt: 'FIRST_UNCOMMITTED' }, 'node context-cli', runtime);
  await handleContextHook('codex', { ...common, hook_event_name: 'UserPromptSubmit', turn_id: 'two', prompt: 'SECOND_UNCOMMITTED' }, 'node context-cli', runtime);
  const output = await handleContextHook('codex', { cwd: root, session_id: 'fresh', hook_event_name: 'SessionStart', source: 'resume' }, 'node context-cli', runtime);
  const text = JSON.stringify(output); expect(text).toContain('FIRST_UNCOMMITTED'); expect(text).toContain('SECOND_UNCOMMITTED'); expect(text).toContain('not accepted decisions');
  expect(await readdir(root)).toEqual(['.git']);
 });
 it('serializes asynchronous session/prompt events without losing pending capture', async () => {
  const { root, runtime } = await setup(); const common = { cwd: root, session_id: 'same-session' };
  await Promise.all([
   handleContextHook('cursor', { ...common, hook_event_name: 'sessionStart' }, 'node context-cli', runtime),
   handleContextHook('cursor', { ...common, hook_event_name: 'beforeSubmitPrompt', prompt: 'decision' }, 'node context-cli', runtime),
  ]);
  const files = (await readdir(runtime)).filter(s => s.endsWith('.json'));
  expect(JSON.parse(await readFile(path.join(runtime, files[0]!), 'utf8')).pending).toBeTruthy();
 });
 it('does not erase existing global hooks and replaces only its managed handlers', () => {
  const existing = { hooks: { Stop: [{ hooks: [{ name: 'someone-else', command: 'existing-command' }] }] }, other: true };
  const first = mergeContextHooks(existing, 'codex', 'node one'); const second = mergeContextHooks(first, 'codex', 'node two');
  expect(second.other).toBe(true); expect((second.hooks as Record<string, unknown[]>).Stop).toHaveLength(2);
  expect(JSON.stringify(second)).toContain('existing-command'); expect(JSON.stringify(second)).not.toContain('node one');
 });
});
