import { afterEach, describe, expect, it } from 'vitest';
import { mkdtemp, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { commitCheckpoint, readCheckpoint, type CheckpointData } from '../src/context-store.js';

const roots: string[] = [];
async function fixture() { const root = await mkdtemp(path.join(os.tmpdir(), 'context-contract-')); roots.push(root); return root; }
const fingerprint = async () => ({ supported: true, gitRoot: '/fixture', head: 'fixture', fingerprint: 'fixture', changedPaths: [] });
const data = (summary: string, extra: Record<string, unknown> = {}): CheckpointData => ({ summary, eventType: 'decision', decisions: [], rejected: [], constraints: [], openIssues: [], next: [], files: [], verification: [], ...extra });
async function tree(root: string): Promise<Record<string, unknown>> {
  const entries: Record<string, unknown> = {};
  async function visit(dir: string) {
    const info = await stat(dir); entries[path.relative(root, dir) || '.'] = { mtime: info.mtimeMs };
    for (const file of (await readdir(dir)).sort()) {
      const full = path.join(dir, file); const s = await stat(full);
      if (s.isDirectory()) await visit(full);
      else entries[path.relative(root, full)] = { text: await readFile(full, 'utf8'), mtime: s.mtimeMs };
    }
  }
  await visit(root); return entries;
}
afterEach(async () => { for (const root of roots.splice(0)) await rm(root, { recursive: true, force: true }); });
describe('global context adoption contracts', () => {
  it('reading an undeclared project creates no files or directories', async () => {
    const root = await fixture(); const before = await tree(root);
    expect(await readCheckpoint(root)).toBeNull(); expect(await tree(root)).toEqual(before);
  });
  it('reading a valid checkpoint never creates/deletes locks or rewrites projections', async () => {
    const root = await fixture(); await commitCheckpoint(root, data('first'), fingerprint);
    const before = await tree(root); await readCheckpoint(root); expect(await tree(root)).toEqual(before);
  });
  it('reads a newer committed journal in memory without repairing stale views', async () => {
    const root = await fixture(); await commitCheckpoint(root, data('first'), fingerprint);
    const old = await tree(root); await commitCheckpoint(root, data('second'), fingerprint);
    for (const name of ['SNAPSHOT.json', 'SESSION_CHECKPOINT.md', 'HANDOFF.md', 'STATE.json']) {
      await writeFile(path.join(root, '.context', name), (old[`.context/${name}`] as { text: string }).text);
    }
    const before = await tree(root); expect((await readCheckpoint(root))?.data.summary).toBe('second');
    expect(await tree(root)).toEqual(before);
  });
  it('rejects external projection edits instead of silently overwriting user decisions', async () => {
    const root = await fixture(); await commitCheckpoint(root, data('first'), fingerprint);
    await writeFile(path.join(root, '.context/HANDOFF.md'), '# Handoff\nUser rejected option A; accepted option B.\n');
    const before = await tree(root);
    await expect(commitCheckpoint(root, data('next'), fingerprint)).rejects.toThrow(/projection|drift|reconcile/i);
    // Lock transient changes can affect directory mtime; content/history must remain intact.
    const after = await tree(root);
    for (const [key, value] of Object.entries(before)) if ('text' in (value as object)) expect((after[key] as { text: string }).text).toBe((value as { text: string }).text);
  });
  it('reconciles drift only with explicit revision and latest semantic state', async () => {
    const root = await fixture(); await commitCheckpoint(root, data('first'), fingerprint);
    await writeFile(path.join(root, '.context/HANDOFF.md'), '# Handoff\nUser rejected A; accepted B.\n');
    await expect(commitCheckpoint(root, data('unsafe', { reconcileProjection: true }), fingerprint)).rejects.toThrow(/revision/i);
    await commitCheckpoint(root, data('reconciled', { reconcileProjection: true, baseRevision: 1, decisions: ['B'], rejected: ['A'] }), fingerprint);
    expect((await readCheckpoint(root))?.data.decisions).toEqual(['B']);
    expect(await readFile(path.join(root, '.context/HANDOFF.md'), 'utf8')).toContain('- B');
  });
  it('does not trust an uncommitted snapshot revision ahead of the journal', async () => {
    const root = await fixture(); await commitCheckpoint(root, data('first'), fingerprint);
    const file = path.join(root, '.context/SNAPSHOT.json'); const s = JSON.parse(await readFile(file, 'utf8'));
    s.revision = 99; s.data.summary = 'uncommitted'; await writeFile(file, JSON.stringify(s));
    expect((await readCheckpoint(root))?.data.summary).toBe('first');
  });
});
