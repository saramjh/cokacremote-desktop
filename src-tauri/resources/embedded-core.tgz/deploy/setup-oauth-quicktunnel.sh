#!/usr/bin/env bash
# cokacremote를 OAuth 2.1 Remote MCP 서버로 구성하고, Cloudflare Quick Tunnel을 통해
# ChatGPT에서 연결 가능한 상태까지 자동으로 기동/검증한다.
#
# 사용법:
#   ./setup-oauth-quicktunnel.sh                          # Quick Tunnel까지 자동 발급
#   ./setup-oauth-quicktunnel.sh https://xxxxx.trycloudflare.com  # 이미 떠 있는 터널 재사용
#
# 전제 조건:
#   - QUICK_TUNNEL_URL을 인자로 주지 않으면 이 스크립트가 cloudflared로 Quick Tunnel을
#     직접 기동한다 (brew install cloudflared 필요). 인자로 URL을 주면 기존 터널을 그대로 사용한다.
#   - cokacremote는 이미 ~/MCPWorkspace 하위 어딘가에 clone되어 있다고 가정한다.
#     새 clone은 만들지 않는다.
#   - 모든 검증을 통과하면 스크립트는 종료하지 않고 포그라운드에 머무르며 로그를 스트리밍한다.
#     Ctrl+C를 누르면 이 스크립트가 띄운 cokacremote(그리고 자동 기동한 터널)를 정리하고 종료한다.
set -euo pipefail

# ------------------------------------------------------------------
# 0) 상수 / 상태
# ------------------------------------------------------------------
WORKSPACE_DIR="$HOME/MCPWorkspace"
STATE_DIR="$HOME/.cokacremote"
APPROVAL_KEY_FILE="$STATE_DIR/oauth-approval-key"
OAUTH_STATE_FILE="$STATE_DIR/oauth-state.json"
START_SCRIPT="$STATE_DIR/start-cokacremote.sh"
LOG_FILE="$STATE_DIR/cokacremote.log"
PID_FILE="$STATE_DIR/cokacremote.pid"
MCP_HOST="127.0.0.1"
MCP_PORT="3000"
HEALTH_URL="http://${MCP_HOST}:${MCP_PORT}/health"
RESOLVE_ARG=""

TUNNEL_LOG="$STATE_DIR/cloudflared.log"
TUNNEL_PID_FILE="$STATE_DIR/cloudflared.pid"

STARTED_BY_SCRIPT=0
STARTED_TUNNEL_BY_SCRIPT=0
# 아래 둘은 검증 성공 후 위 두 플래그가 0으로 리셋되더라도, 이 실행이 실제로 서버/터널을
# 기동했는지를 영구적으로 기억해, 마지막 Ctrl+C 종료 처리에 사용한다.
SERVER_OWNED_BY_SCRIPT=0
TUNNEL_OWNED_BY_SCRIPT=0
SERVER_PID=""
TUNNEL_PID=""
TAIL_PID=""
REPO_DIR=""
AUTO_TUNNEL_URL=""

log()  { printf '\n[%s] %s\n' "$(date '+%H:%M:%S')" "$*"; }
warn() { printf '\n[%s] ⚠ %s\n' "$(date '+%H:%M:%S')" "$*"; }

# 이 스크립트가 직접 기동한 프로세스만 정리한다. 사용자가 별도로 이미 띄워둔
# 프로세스나 터널은 (인자로 URL을 넘겨 재사용한 경우) 절대 건드리지 않는다.
cleanup_on_failure() {
  if [[ "$STARTED_BY_SCRIPT" -eq 1 && -n "$SERVER_PID" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
    log "롤백: 이 스크립트가 시작한 cokacremote 프로세스(PID $SERVER_PID)를 종료합니다."
    kill "$SERVER_PID" 2>/dev/null || true
    for _ in $(seq 1 10); do
      kill -0 "$SERVER_PID" 2>/dev/null || break
      sleep 0.5
    done
    kill -9 "$SERVER_PID" 2>/dev/null || true
  fi
  if [[ "$STARTED_TUNNEL_BY_SCRIPT" -eq 1 && -n "$TUNNEL_PID" ]] && kill -0 "$TUNNEL_PID" 2>/dev/null; then
    log "롤백: 이 스크립트가 시작한 cloudflared 터널(PID $TUNNEL_PID)을 종료합니다."
    kill "$TUNNEL_PID" 2>/dev/null || true
    for _ in $(seq 1 10); do
      kill -0 "$TUNNEL_PID" 2>/dev/null || break
      sleep 0.5
    done
    kill -9 "$TUNNEL_PID" 2>/dev/null || true
  fi
}

fail() {
  printf '\n[%s] ❌ %s\n' "$(date '+%H:%M:%S')" "$*" >&2
  cleanup_on_failure
  exit 1
}

on_err() { fail "예상치 못한 오류가 발생했습니다 (${BASH_SOURCE[0]}:${LINENO})"; }
on_int() { log "인터럽트 수신, 정리 중..."; cleanup_on_failure; exit 130; }
trap on_err ERR
trap on_int INT TERM

# JSON 응답에서 값을 안전하게 추출한다 (셸 인젝션 없이 process.argv로 전달).
json_get() {
  node -e '
    try {
      const data = JSON.parse(process.argv[1]);
      const value = new Function("d", "return (" + process.argv[2] + ");")(data);
      process.stdout.write(value === undefined || value === null ? "" : String(value));
    } catch (e) {
      process.stdout.write("");
    }
  ' "$1" "$2" 2>/dev/null
}

extract_hostname() {
  node -e '
    try { process.stdout.write(new URL(process.argv[1]).hostname); }
    catch (e) { process.stdout.write(""); }
  ' "$1" 2>/dev/null
}

# 사용자 시스템 DNS(느린 ISP 리졸버이거나, macOS 리졸버가 이런 형태의 도메인을 아예
# 못 푸는 경우도 있음)를 거치지 않고, 공용 DNS(1.1.1.1/8.8.8.8/9.9.9.9)로 직접 조회해
# IP를 얻는다. 터널이 막 생성된 직후라 공용 DNS에도 아직 안 올라와 있을 수 있으므로
# 최대 15초 정도 짧게 재시도한다. 이 IP는 curl --resolve로 넘겨 시스템 리졸버를 우회한다.
resolve_ip_public_dns() {
  local host="$1" attempts="${2:-5}" ip="" resolver
  command -v dig >/dev/null 2>&1 || return 1
  for _ in $(seq 1 "$attempts"); do
    for resolver in 1.1.1.1 8.8.8.8 9.9.9.9; do
      ip="$(dig +time=2 +tries=1 "@${resolver}" +short "$host" A 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1)"
      [[ -n "$ip" ]] && { echo "$ip"; return 0; }
    done
    [[ "$attempts" -gt 1 ]] && sleep 1
  done
  return 1
}

# BASE_URL/TUNNEL_HOST가 (재)설정될 때마다 호출해, 공개 curl 호출이 시스템 DNS 대신
# 이 IP로 바로 붙게 만든다. 실패하면 RESOLVE_ARG를 비워 평소대로 시스템 DNS를 쓴다
# (다만 시스템 DNS는 이런 도메인에서 아예 안 풀릴 수도 있음을 감안해야 한다).
update_resolve_arg() {
  RESOLVE_ARG=""
  local ip
  if ip="$(resolve_ip_public_dns "$TUNNEL_HOST")"; then
    RESOLVE_ARG="--resolve ${TUNNEL_HOST}:443:${ip}"
    log "  공용 DNS로 사전 확인: $TUNNEL_HOST → $ip (시스템 DNS 우회)"
  else
    warn "공용 DNS로도 hostname을 확인하지 못했습니다 (15초 재시도 후). 시스템 DNS로 진행하지만 실패할 수 있습니다"
  fi
}

# HTTP status + body를 함께 확인하고, JSON 파싱 가능 여부까지 검증한다.
check_json_endpoint() {
  local url="$1" tmp
  tmp="$(mktemp)"
  local code
  code="$(curl -s $RESOLVE_ARG -o "$tmp" -w '%{http_code}' "$url" 2>/dev/null || true)"
  code="${code:-000}"
  if [[ "$code" != "200" ]]; then
    rm -f "$tmp"
    echo "FAIL (HTTP $code)"
    return 1
  fi
  if ! node -e 'JSON.parse(require("fs").readFileSync(process.argv[1], "utf8"))' "$tmp" >/dev/null 2>&1; then
    rm -f "$tmp"
    echo "FAIL (JSON 아님)"
    return 1
  fi
  cat "$tmp"
  rm -f "$tmp"
  return 0
}

get_cwd_of_pid() {
  lsof -a -p "$1" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | grep '^/' | head -n1
}

# cloudflared로 Quick Tunnel을 직접 기동한다. 반드시 명령치환($(...))이 아닌
# 직접 호출로 써야 TUNNEL_PID/소유권 플래그가 서브셸에 갇혀 사라지지 않는다.
# 결과는 AUTO_TUNNEL_URL 전역변수에 담는다.
start_auto_tunnel() {
  command -v cloudflared >/dev/null 2>&1 || fail "cloudflared가 설치되어 있지 않습니다. 'brew install cloudflared'로 설치하세요."
  : > "$TUNNEL_LOG"
  chmod 600 "$TUNNEL_LOG"
  nohup cloudflared tunnel --url "http://${MCP_HOST}:${MCP_PORT}" >>"$TUNNEL_LOG" 2>&1 &
  TUNNEL_PID=$!
  STARTED_TUNNEL_BY_SCRIPT=1
  TUNNEL_OWNED_BY_SCRIPT=1
  disown "$TUNNEL_PID" 2>/dev/null || true
  echo "$TUNNEL_PID" > "$TUNNEL_PID_FILE"
  log "  cloudflared 기동 (PID $TUNNEL_PID, 로그: $TUNNEL_LOG)"

  local url=""
  for _ in $(seq 1 30); do
    if ! kill -0 "$TUNNEL_PID" 2>/dev/null; then
      fail "cloudflared 프로세스가 조기 종료되었습니다. 로그 확인: tail -n 50 $TUNNEL_LOG"
    fi
    url="$(grep -Eo 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' "$TUNNEL_LOG" 2>/dev/null | head -n1 || true)"
    [[ -n "$url" ]] && break
    sleep 1
  done
  [[ -n "$url" ]] || fail "Quick Tunnel URL을 30초 내에 확인하지 못했습니다. 로그 확인: tail -n 50 $TUNNEL_LOG"
  AUTO_TUNNEL_URL="$url"
}

# ------------------------------------------------------------------
# 0) Quick Tunnel 확보 (인자로 URL이 없으면 자동 발급)
# ------------------------------------------------------------------
mkdir -p "$STATE_DIR"
QUICK_TUNNEL_URL="${1:-${QUICK_TUNNEL_URL:-}}"
if [[ -z "$QUICK_TUNNEL_URL" ]]; then
  AUTO_MODE=1
  log "0) QUICK_TUNNEL_URL 미지정 → cloudflared로 Quick Tunnel 자동 발급"
  start_auto_tunnel
  QUICK_TUNNEL_URL="$AUTO_TUNNEL_URL"
  log "  발급된 Quick Tunnel URL: $QUICK_TUNNEL_URL"
else
  AUTO_MODE=0
  log "0) 기존 Quick Tunnel URL 재사용 (이 스크립트는 관리하지 않음): $QUICK_TUNNEL_URL"
fi
BASE_URL="${QUICK_TUNNEL_URL%/}"
[[ "$BASE_URL" =~ ^https?:// ]] || fail "QUICK_TUNNEL_URL이 올바른 URL 형식이 아닙니다: $QUICK_TUNNEL_URL"

# ------------------------------------------------------------------
# 1) 현재 cokacremote 로컬 상태 확인
# ------------------------------------------------------------------
log "1) 로컬 헬스체크: $HEALTH_URL"
EXISTING_HEALTH_JSON=""
if EXISTING_HEALTH_JSON="$(curl -fsS "$HEALTH_URL" 2>/dev/null)"; then
  [[ "$(json_get "$EXISTING_HEALTH_JSON" 'd.status')" == "ok" ]] || fail "기존 health.status가 ok가 아닙니다"
  [[ "$(json_get "$EXISTING_HEALTH_JSON" 'd.service')" == "cokacremote" ]] || fail "기존 health.service가 cokacremote가 아닙니다"
  log "  기존 cokacremote가 3000번 포트에서 정상 응답 중"
else
  warn "로컬 /health 응답 없음 (프로세스가 없거나 아직 기동 전일 수 있음)"
fi

log "  3000번 포트 리스닝 PID 확인"
LISTEN_PID="$(lsof -nP -iTCP:3000 -sTCP:LISTEN -t 2>/dev/null | head -n1 || true)"
if [[ -n "$LISTEN_PID" ]]; then
  log "  리스닝 PID: $LISTEN_PID"
  ps -p "$LISTEN_PID" -o pid,ppid,command || true
  REPO_DIR="$(get_cwd_of_pid "$LISTEN_PID")"
  log "  탐지된 cwd: ${REPO_DIR:-<확인 실패>}"
else
  log "  3000번 포트에 리스닝 중인 프로세스가 없습니다."
fi

# ------------------------------------------------------------------
# 2) 실제 cokacremote repository 검증
# ------------------------------------------------------------------
log "2) cokacremote 저장소 검증"
if [[ -z "$REPO_DIR" || ! -f "$REPO_DIR/package.json" ]]; then
  [[ -f "$WORKSPACE_DIR/cokacremote/package.json" ]] || fail "cokacremote 설치 위치를 찾을 수 없습니다. 임의로 clone하지 않습니다."
  REPO_DIR="$WORKSPACE_DIR/cokacremote"
  warn "실행 중인 프로세스의 cwd를 확인할 수 없어, 워크스페이스 내 기존 설치로 대체합니다: $REPO_DIR"
fi

PKG_NAME="$(node -e 'try{process.stdout.write(require(process.argv[1]+"/package.json").name||"");}catch(e){process.stdout.write("");}' "$REPO_DIR")"
[[ "$PKG_NAME" == "cokacremote" ]] || fail "package.json의 name이 cokacremote가 아닙니다 (실제: '$PKG_NAME', 위치: $REPO_DIR)"

HAS_START_SCRIPT="$(node -e 'try{process.stdout.write(require(process.argv[1]+"/package.json").scripts.start||"");}catch(e){process.stdout.write("");}' "$REPO_DIR")"
[[ -n "$HAS_START_SCRIPT" ]] || fail "package.json에 start 스크립트가 없습니다"

if git -C "$REPO_DIR" remote -v 2>/dev/null | grep -qi "kstost/cokacremote"; then
  log "  git remote 확인: kstost/cokacremote 기반"
else
  warn "git remote가 kstost/cokacremote를 가리키지 않습니다 (계속 진행)"
fi
log "  저장소 검증 완료: $REPO_DIR"

# ------------------------------------------------------------------
# 3) Quick Tunnel URL 검증
# ------------------------------------------------------------------
log "3) Quick Tunnel 검증: $BASE_URL"
TUNNEL_HOST="$(extract_hostname "$BASE_URL")"
[[ -n "$TUNNEL_HOST" ]] || fail "Quick Tunnel hostname을 추출하지 못했습니다: $BASE_URL"
log "  추출된 hostname: $TUNNEL_HOST"
update_resolve_arg

# 이 사전 점검은 "사용자가 이미 한동안 떠 있던 기존 터널 URL을 인자로 넘긴 경우"에만
# 의미가 있다. 방금 자동 발급한 새 터널은 라우팅이 아직 안 붙었을 수 있으므로
# (뒤쪽 8~9단계에서 재시도 로직으로 다시 검증하니) 여기서는 건너뛴다.
if [[ -n "$LISTEN_PID" && "$AUTO_MODE" -eq 0 ]]; then
  PRE_PUBLIC_HEALTH="$(curl -fsS $RESOLVE_ARG "$BASE_URL/health" 2>&1)" || fail "Quick Tunnel을 통한 공개 접근 실패: $BASE_URL/health (원인: cloudflared 터널 상태 또는 방화벽 확인 필요)"
  [[ "$(json_get "$PRE_PUBLIC_HEALTH" 'd.service')" == "cokacremote" ]] || fail "공개 /health 응답이 cokacremote 서비스가 아닙니다"
  log "  공개 /health 사전 확인 완료 (OAuth 적용 전)"
elif [[ -n "$LISTEN_PID" ]]; then
  log "  자동 발급된 새 터널이라 사전 공개 확인은 건너뜁니다 (8~9단계에서 재시도 포함하여 검증)"
fi

# ------------------------------------------------------------------
# 4) OAuth state 디렉터리 준비
# ------------------------------------------------------------------
log "4) OAuth 상태 디렉터리 준비: $STATE_DIR"
mkdir -p "$STATE_DIR"
chmod 700 "$STATE_DIR"

if [[ -s "$APPROVAL_KEY_FILE" ]]; then
  log "  기존 approval key 재사용 (재생성하지 않음)"
else
  ( umask 077; openssl rand -hex 32 > "$APPROVAL_KEY_FILE" )
  chmod 600 "$APPROVAL_KEY_FILE"
  log "  새 approval key 생성 완료"
fi
[[ "$(wc -c < "$APPROVAL_KEY_FILE" | tr -d ' ')" -ge 32 ]] || fail "approval key 파일 내용이 비정상적으로 짧습니다"
APPROVAL_KEY="$(cat "$APPROVAL_KEY_FILE")"

# ------------------------------------------------------------------
# 5) 기존 프로세스 종료 (실제 cokacremote인 경우에만)
# ------------------------------------------------------------------
log "5) 기존 프로세스 정리"
if [[ -n "$LISTEN_PID" ]]; then
  PROC_CWD="$(get_cwd_of_pid "$LISTEN_PID")"
  PROC_CMD="$(ps -p "$LISTEN_PID" -o command= 2>/dev/null || true)"
  if [[ "$PROC_CWD" == "$REPO_DIR" && "$PROC_CMD" == *"server.js"* ]]; then
    log "  PID $LISTEN_PID 가 실제 cokacremote 프로세스임을 확인, 정상 종료(SIGTERM) 시도"
    kill "$LISTEN_PID" 2>/dev/null || true
    for _ in $(seq 1 20); do
      kill -0 "$LISTEN_PID" 2>/dev/null || break
      sleep 0.5
    done
    if kill -0 "$LISTEN_PID" 2>/dev/null; then
      warn "SIGTERM 후에도 종료되지 않아 SIGKILL 전송"
      kill -9 "$LISTEN_PID" 2>/dev/null || true
    fi
    log "  기존 프로세스 종료 완료"
  else
    fail "3000번 포트의 PID $LISTEN_PID 가 cokacremote로 확인되지 않아 종료를 중단합니다 (cwd=$PROC_CWD, cmd=$PROC_CMD)"
  fi
else
  log "  종료할 기존 프로세스 없음"
fi

# ------------------------------------------------------------------
# 6) 빌드 확인
# ------------------------------------------------------------------
log "6) 빌드 산출물 확인"
if [[ ! -f "$REPO_DIR/dist/src/server.js" ]]; then
  log "  dist 산출물이 없어 빌드를 실행합니다 (npm run build)"
  ( cd "$REPO_DIR" && npm run build ) || fail "빌드 실패"
else
  log "  기존 빌드 산출물 재사용"
fi

# ------------------------------------------------------------------
# 7) 실행 스크립트 생성 (~/.cokacremote/start-cokacremote.sh)
# ------------------------------------------------------------------
log "7) 실행 스크립트 생성: $START_SCRIPT"
cat > "$START_SCRIPT" <<STARTEOF
#!/usr/bin/env bash
# OAuth 2.1 + Quick Tunnel 구성으로 cokacremote를 기동한다.
# approval key는 파일에서만 읽으며, 이 스크립트에 하드코딩하지 않는다.
# 사용법: start-cokacremote.sh <QUICK_TUNNEL_URL>
set -euo pipefail

REPO_DIR="$REPO_DIR"
STATE_DIR="$STATE_DIR"
APPROVAL_KEY_FILE="\$STATE_DIR/oauth-approval-key"

QUICK_TUNNEL_URL="\${1:-\${QUICK_TUNNEL_URL:-}}"
if [[ -z "\$QUICK_TUNNEL_URL" ]]; then
  echo "사용법: \$0 <QUICK_TUNNEL_URL>  (Quick Tunnel 주소가 재발급되면 이 인자만 바꾸면 됩니다)" >&2
  exit 1
fi
BASE_URL="\${QUICK_TUNNEL_URL%/}"
TUNNEL_HOST="\$(node -e 'try{process.stdout.write(new URL(process.argv[1]).hostname);}catch(e){process.stdout.write("");}' "\$BASE_URL")"
[[ -n "\$TUNNEL_HOST" ]] || { echo "Quick Tunnel hostname 추출 실패: \$BASE_URL" >&2; exit 1; }

[[ -s "\$APPROVAL_KEY_FILE" ]] || { echo "approval key 파일이 없습니다: \$APPROVAL_KEY_FILE" >&2; exit 1; }

export MCP_HOST="127.0.0.1"
export MCP_PORT="3000"
export MCP_DEFAULT_CWD="\$HOME/MCPWorkspace"
export MCP_DEFAULT_SHELL="/bin/zsh"
export MCP_PUBLIC_URL="\$BASE_URL"
export MCP_ALLOWED_HOSTS="\$TUNNEL_HOST,127.0.0.1,localhost"
export MCP_TRUST_PROXY_HOPS="1"
export MCP_AUTH_TOKEN=""
export MCP_ALLOW_NO_AUTH="false"
export MCP_OAUTH_ENABLED="true"
export MCP_OAUTH_APPROVAL_KEY="\$(cat "\$APPROVAL_KEY_FILE")"
export MCP_OAUTH_ISSUER="\$BASE_URL"
export MCP_OAUTH_RESOURCE="\$BASE_URL/mcp"
export MCP_OAUTH_STATE_FILE="\$STATE_DIR/oauth-state.json"

cd "\$REPO_DIR"
exec node dist/src/server.js
STARTEOF
chmod 700 "$START_SCRIPT"
log "  생성 완료 (700 권한)"

# ------------------------------------------------------------------
# 8~9) 서버 기동 + 헬스체크 (Quick Tunnel이 불안정할 수 있어 자동 발급 모드에서는
#      공개 /health가 끝내 응답 없으면 새 터널로 재시도한다)
# ------------------------------------------------------------------
MAX_TUNNEL_ATTEMPTS=3
tunnel_attempt=1

while true; do
  log "8) 서버 기동 (백그라운드, 시도 $tunnel_attempt/$MAX_TUNNEL_ATTEMPTS)"
  : > "$LOG_FILE"
  chmod 600 "$LOG_FILE"
  nohup "$START_SCRIPT" "$BASE_URL" >>"$LOG_FILE" 2>&1 &
  SERVER_PID=$!
  STARTED_BY_SCRIPT=1
  SERVER_OWNED_BY_SCRIPT=1
  disown "$SERVER_PID" 2>/dev/null || true
  echo "$SERVER_PID" > "$PID_FILE"
  log "  PID: $SERVER_PID (로그: $LOG_FILE)"

  log "  헬스체크 대기 중 (최대 30초)..."
  READY=0
  NEW_HEALTH_JSON=""
  for _ in $(seq 1 30); do
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
      fail "서버 프로세스가 조기 종료되었습니다. 로그 확인: tail -n 50 $LOG_FILE"
    fi
    if NEW_HEALTH_JSON="$(curl -fsS "$HEALTH_URL" 2>/dev/null)"; then
      READY=1
      break
    fi
    sleep 1
  done
  [[ "$READY" -eq 1 ]] || fail "헬스체크 타임아웃 (30초). 로그 확인: tail -n 50 $LOG_FILE"

  log "9) OAuth 활성화 검증"
  [[ "$(json_get "$NEW_HEALTH_JSON" 'd.status')" == "ok" ]] || fail "재기동 후 health.status != ok"
  [[ "$(json_get "$NEW_HEALTH_JSON" 'd.service')" == "cokacremote" ]] || fail "재기동 후 health.service != cokacremote"
  [[ "$(json_get "$NEW_HEALTH_JSON" 'd.oauthEnabled')" == "true" ]] || fail "재기동 후 health.oauthEnabled != true"
  LOCAL_HEALTH_STATUS="pass (status=ok, service=cokacremote, oauthEnabled=true)"
  log "  로컬 헬스체크: $LOCAL_HEALTH_STATUS"

  # cloudflared Quick Tunnel은 URL 발급 후 실제 라우팅이 붙기까지 20~30초 정도
  # 걸리는 경우가 흔하므로(엣지 전파 지연), 넉넉하게 최대 60초까지 재시도한다.
  # (공용 DNS로 직접 조회한 IP를 쓰므로, 느린/버그 있는 시스템 DNS로 인한 대기는 대부분 사라진다.
  #  터널 생성 직후라 공용 DNS에도 아직 없었다면, 이 루프 안에서도 주기적으로 재조회한다)
  PUBLIC_HEALTH_HTTP="000"
  for i in $(seq 1 60); do
    if [[ -z "$RESOLVE_ARG" ]]; then
      ip="$(dig +time=1 +tries=1 @1.1.1.1 +short "$TUNNEL_HOST" A 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1)"
      if [[ -n "$ip" ]]; then
        RESOLVE_ARG="--resolve ${TUNNEL_HOST}:443:${ip}"
        log "  공용 DNS 조회 성공: $TUNNEL_HOST → $ip (이제부터 시스템 DNS 우회)"
      fi
    fi
    PUBLIC_HEALTH_HTTP="$(curl -s $RESOLVE_ARG -o /tmp/cokacremote-public-health.$$ -w '%{http_code}' "$BASE_URL/health" 2>/dev/null || true)"
    PUBLIC_HEALTH_HTTP="${PUBLIC_HEALTH_HTTP:-000}"
    [[ "$PUBLIC_HEALTH_HTTP" == "200" ]] && break
    if (( i % 5 == 0 )); then
      log "  아직 라우팅 대기 중... (${i}초 경과, 마지막 응답: HTTP $PUBLIC_HEALTH_HTTP)"
    fi
    sleep 1
  done

  if [[ "$PUBLIC_HEALTH_HTTP" == "200" ]]; then
    PUBLIC_HEALTH_JSON="$(cat /tmp/cokacremote-public-health.$$)"; rm -f /tmp/cokacremote-public-health.$$
    [[ "$(json_get "$PUBLIC_HEALTH_JSON" 'd.oauthEnabled')" == "true" ]] || fail "공개 /health의 oauthEnabled != true"
    PUBLIC_HEALTH_STATUS="pass (HTTP $PUBLIC_HEALTH_HTTP, oauthEnabled=true)"
    log "  공개 헬스체크: $PUBLIC_HEALTH_STATUS"
    break
  fi

  rm -f /tmp/cokacremote-public-health.$$
  if [[ "$AUTO_MODE" -eq 1 && "$tunnel_attempt" -lt "$MAX_TUNNEL_ATTEMPTS" ]]; then
    tunnel_attempt=$((tunnel_attempt + 1))
    warn "Quick Tunnel($BASE_URL)이 60초 내에 응답하지 않았습니다 (Quick Tunnel은 종종 불안정합니다). 새 터널로 재시도합니다 ($tunnel_attempt/$MAX_TUNNEL_ATTEMPTS)"
    if kill -0 "$SERVER_PID" 2>/dev/null; then
      kill "$SERVER_PID" 2>/dev/null || true
      sleep 1
      kill -9 "$SERVER_PID" 2>/dev/null || true
    fi
    if kill -0 "$TUNNEL_PID" 2>/dev/null; then
      kill "$TUNNEL_PID" 2>/dev/null || true
      sleep 1
      kill -9 "$TUNNEL_PID" 2>/dev/null || true
    fi
    start_auto_tunnel
    QUICK_TUNNEL_URL="$AUTO_TUNNEL_URL"
    BASE_URL="${QUICK_TUNNEL_URL%/}"
    TUNNEL_HOST="$(extract_hostname "$BASE_URL")"
    update_resolve_arg
    continue
  fi

  fail "공개 /health 실패 (HTTP $PUBLIC_HEALTH_HTTP, ${tunnel_attempt}회 시도). Quick Tunnel이 127.0.0.1:3000으로 정상 라우팅되는지, 방화벽이 막고 있지 않은지 확인하세요. 로그: tail -n 50 $TUNNEL_LOG"
done

# ------------------------------------------------------------------
# 10) OAuth discovery endpoint 검증
# ------------------------------------------------------------------
log "10) OAuth discovery 엔드포인트 검증"

PROTECTED_RESOURCE_JSON="$(check_json_endpoint "$BASE_URL/.well-known/oauth-protected-resource" || true)"
if [[ "$PROTECTED_RESOURCE_JSON" == FAIL* ]]; then
  fail "/.well-known/oauth-protected-resource 검증 실패: $PROTECTED_RESOURCE_JSON"
fi
PROTECTED_RESOURCE_STATUS="pass"

PROTECTED_RESOURCE_MCP_JSON="$(check_json_endpoint "$BASE_URL/.well-known/oauth-protected-resource/mcp" || true)"
if [[ "$PROTECTED_RESOURCE_MCP_JSON" == FAIL* ]]; then
  PROTECTED_RESOURCE_MCP_STATUS="$PROTECTED_RESOURCE_MCP_JSON"
  warn "/.well-known/oauth-protected-resource/mcp: $PROTECTED_RESOURCE_MCP_STATUS (기본 경로는 정상이므로 계속 진행)"
else
  PROTECTED_RESOURCE_MCP_STATUS="pass"
fi

AUTH_SERVER_JSON="$(check_json_endpoint "$BASE_URL/.well-known/oauth-authorization-server" || true)"
if [[ "$AUTH_SERVER_JSON" == FAIL* ]]; then
  fail "/.well-known/oauth-authorization-server 검증 실패: $AUTH_SERVER_JSON"
fi
AUTH_SERVER_STATUS="pass"

RESOURCE_VAL="$(json_get "$PROTECTED_RESOURCE_JSON" 'd.resource')"
ISSUER_FROM_RESOURCE="$(json_get "$PROTECTED_RESOURCE_JSON" 'd.authorization_servers && d.authorization_servers[0]')"
[[ "$RESOURCE_VAL" == "$BASE_URL/mcp" ]] || fail "protected-resource.resource 불일치 (실제: $RESOURCE_VAL, 기대: $BASE_URL/mcp)"
[[ "$ISSUER_FROM_RESOURCE" == "$BASE_URL" || "$ISSUER_FROM_RESOURCE" == "$BASE_URL/" ]] || fail "protected-resource.authorization_servers[0] 불일치 (실제: $ISSUER_FROM_RESOURCE, 기대: $BASE_URL)"

AS_ISSUER="$(json_get "$AUTH_SERVER_JSON" 'd.issuer')"
AS_AUTHZ="$(json_get "$AUTH_SERVER_JSON" 'd.authorization_endpoint')"
AS_TOKEN="$(json_get "$AUTH_SERVER_JSON" 'd.token_endpoint')"
AS_REG="$(json_get "$AUTH_SERVER_JSON" 'd.registration_endpoint')"
[[ "$AS_ISSUER" == "$BASE_URL" || "$AS_ISSUER" == "$BASE_URL/" ]] || fail "authorization-server.issuer 불일치 (실제: $AS_ISSUER, 기대: $BASE_URL)"
[[ -n "$AS_AUTHZ" && -n "$AS_TOKEN" && -n "$AS_REG" ]] || fail "authorization-server metadata에 authorize/token/registration endpoint 누락"
log "  discovery metadata 검증 완료 (issuer/resource 일관성 확인)"

# ------------------------------------------------------------------
# 11) 인증되지 않은 /mcp 접근 차단 확인
# ------------------------------------------------------------------
log "11) 인증되지 않은 /mcp 접근 차단 확인"
MCP_UNAUTH_HTTP="$(curl -s $RESOLVE_ARG -o /dev/null -w '%{http_code}' "$BASE_URL/mcp" 2>/dev/null || true)"
MCP_UNAUTH_HTTP="${MCP_UNAUTH_HTTP:-000}"
[[ "$MCP_UNAUTH_HTTP" == "401" ]] || fail "/mcp 익명 접근이 401이 아닙니다 (실제: $MCP_UNAUTH_HTTP) — 보안 위험, MCP_ALLOW_NO_AUTH가 true로 새는지 확인 필요"
MCP_UNAUTH_STATUS="pass (401 Unauthorized)"

# 검증 완료 이후에는 이 스크립트 종료 시 서버/터널을 죽이지 않는다.
trap - ERR INT TERM
STARTED_BY_SCRIPT=0
STARTED_TUNNEL_BY_SCRIPT=0

if [[ -n "$TUNNEL_PID" ]]; then
  TUNNEL_OWNER_DISPLAY="이 스크립트가 자동 기동"
  TUNNEL_LOG_DISPLAY="$TUNNEL_LOG"
  TUNNEL_STOP_DISPLAY="kill $TUNNEL_PID"
else
  TUNNEL_OWNER_DISPLAY="사용자가 직접 관리 (URL만 사용)"
  TUNNEL_LOG_DISPLAY="N/A"
  TUNNEL_STOP_DISPLAY="N/A (사용자가 직접 관리)"
fi

log "✅ 모든 검증 통과"

cat <<SUMMARY

============================================================
 cokacremote Remote MCP — 연결 정보
============================================================
ChatGPT에 등록할 MCP URL : $BASE_URL/mcp
Authentication           : OAuth 2.1
Client registration      : Dynamic Client Registration (DCR)
Scope                    : mcp:tools

OAuth approval key (발급된 토큰 — 외부에 공유하지 마세요):
  $APPROVAL_KEY
  (다음에 다시 확인하려면: cat $APPROVAL_KEY_FILE)

cokacremote 프로세스:
  PID             : $SERVER_PID
  Repo            : $REPO_DIR
  Log             : $LOG_FILE
  중지            : kill $SERVER_PID
  재시작 스크립트: $START_SCRIPT $BASE_URL
  (Quick Tunnel 주소가 바뀌면 위 스크립트의 인자만 새 주소로 바꿔서 재실행)

Quick Tunnel (cloudflared):
  관리 주체       : $TUNNEL_OWNER_DISPLAY
  PID             : ${TUNNEL_PID:-N/A}
  Log             : ${TUNNEL_LOG_DISPLAY:-N/A}
  중지            : ${TUNNEL_STOP_DISPLAY:-N/A (사용자가 직접 관리)}
  주의            : Quick Tunnel URL은 cloudflared 프로세스가 살아있는 동안만 유효한 임시 주소입니다.
                    재시작하면 URL이 바뀌므로, 재발급 시 재시작 스크립트에 새 URL을 다시 넘겨야 합니다.

검증 결과:
  local  /health                              : $LOCAL_HEALTH_STATUS
  public /health                              : $PUBLIC_HEALTH_STATUS
  /.well-known/oauth-protected-resource       : $PROTECTED_RESOURCE_STATUS
  /.well-known/oauth-protected-resource/mcp   : $PROTECTED_RESOURCE_MCP_STATUS
  /.well-known/oauth-authorization-server     : $AUTH_SERVER_STATUS
  /mcp (unauthenticated)                      : $MCP_UNAUTH_STATUS
============================================================
SUMMARY

# ------------------------------------------------------------------
# 12) 실행 상태 유지 (Ctrl+C로 정리 가능하게 포그라운드에 붙는다)
# ------------------------------------------------------------------
# Ctrl+C를 누르면 이 스크립트가 소유한 프로세스만 종료한다.
# (인자로 넘겨받아 재사용한 기존 Quick Tunnel은 여기서도 건드리지 않는다.)
on_int_foreground() {
  echo
  log "Ctrl+C 감지: 종료 절차 시작"
  if [[ -n "$TAIL_PID" ]] && kill -0 "$TAIL_PID" 2>/dev/null; then
    kill "$TAIL_PID" 2>/dev/null || true
  fi
  if [[ -n "$SERVER_PID" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
    log "  cokacremote(PID $SERVER_PID) 종료 중..."
    kill "$SERVER_PID" 2>/dev/null || true
    for _ in $(seq 1 10); do
      kill -0 "$SERVER_PID" 2>/dev/null || break
      sleep 0.5
    done
    kill -9 "$SERVER_PID" 2>/dev/null || true
    log "  cokacremote 종료 완료"
  fi
  if [[ "$TUNNEL_OWNED_BY_SCRIPT" -eq 1 && -n "$TUNNEL_PID" ]] && kill -0 "$TUNNEL_PID" 2>/dev/null; then
    log "  cloudflared(PID $TUNNEL_PID) 종료 중... (이 스크립트가 자동 기동한 터널)"
    kill "$TUNNEL_PID" 2>/dev/null || true
    for _ in $(seq 1 10); do
      kill -0 "$TUNNEL_PID" 2>/dev/null || break
      sleep 0.5
    done
    kill -9 "$TUNNEL_PID" 2>/dev/null || true
    log "  cloudflared 종료 완료"
  else
    log "  Quick Tunnel은 사용자가 직접 관리 중이므로 그대로 둡니다."
  fi
  exit 0
}
trap on_int_foreground INT TERM

log "실행 상태 유지 중 (로그 실시간 출력). 종료하려면 Ctrl+C를 누르세요."
tail -n0 -f "$LOG_FILE" &
TAIL_PID=$!
wait "$TAIL_PID"
